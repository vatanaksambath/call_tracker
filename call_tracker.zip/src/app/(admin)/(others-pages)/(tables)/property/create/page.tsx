"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import ComponentCard from "@/components/common/ComponentCard";
import Button from "@/components/ui/button/Button";
import Label from "@/components/form/Label";
import Input from "@/components/form/input/InputField";
import TextArea from "@/components/form/input/TextArea";
import Select from "@/components/form/Select";
import { Modal } from "@/components/ui/modal";
import Address, { IAddress } from "@/components/form/Address";

const breadcrumbs = [
  { name: "Home", href: "/" },
  { name: "Property", href: "/property" },
  { name: "Create", href: "/property/create" }
];

interface ISelectOption {
  value: string;
  label: string;
}

interface FormData {
  PropertyName: string;
  Location: IAddress;
  PropertyType: ISelectOption | null;
  Status: ISelectOption | null;
  Price: string;
  Description: string;
  Features: string;
  Bedrooms: string;
  Bathrooms: string;
  Area: string;
  YearBuilt: string;
}

interface FormErrors {
  PropertyName?: string;
  Location?: string;
  PropertyType?: string;
  Status?: string;
  Price?: string;
  Description?: string;
  Features?: string;
  Bedrooms?: string;
  Bathrooms?: string;
  Area?: string;
  YearBuilt?: string;
}

export default function CreatePropertyPage() {
  const router = useRouter();
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState<FormData>({
    PropertyName: "",
    Location: {
      province: null,
      district: null,
      commune: null,
      village: null,
      homeAddress: "",
      streetAddress: ""
    },
    PropertyType: null,
    Status: null,
    Price: "",
    Description: "",
    Features: "",
    Bedrooms: "",
    Bathrooms: "",
    Area: "",
    YearBuilt: "",
  });
  
  const [errors, setErrors] = useState<FormErrors>({});

  // Property Type Options
  const propertyTypeOptions: ISelectOption[] = [
    { value: "Villa", label: "Villa" },
    { value: "Condominium", label: "Condominium" },
    { value: "House", label: "House" },
    { value: "Apartment", label: "Apartment" },
    { value: "Townhouse", label: "Townhouse" },
    { value: "Studio", label: "Studio" },
    { value: "Penthouse", label: "Penthouse" },
    { value: "Cottage", label: "Cottage" },
    { value: "Lodge", label: "Lodge" },
    { value: "Loft", label: "Loft" },
    { value: "Manor", label: "Manor" },
    { value: "Cabin", label: "Cabin" },
    { value: "Estate", label: "Estate" },
    { value: "Flat", label: "Flat" },
  ];

  // Status Options
  const statusOptions: ISelectOption[] = [
    { value: "Available", label: "Available" },
    { value: "Reserved", label: "Reserved" },
    { value: "Sold", label: "Sold" },
    { value: "Under Construction", label: "Under Construction" },
    { value: "Maintenance", label: "Maintenance" },
  ];

  const handleChange = (field: keyof FormData, value: string | boolean | ISelectOption | null | IAddress) => {
    console.log("Property form handleChange:", field, value);
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors[field as keyof FormErrors]) {
      setErrors(prev => ({
        ...prev,
        [field]: undefined
      }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};
    if (!formData.PropertyName.trim()) {
      newErrors.PropertyName = "Property name is required";
    }
    if (!formData.Location.province) {
      newErrors.Location = "Location is required";
    }
    if (!formData.PropertyType) {
      newErrors.PropertyType = "Property type is required";
    }
    if (!formData.Status) {
      newErrors.Status = "Status is required";
    }
    if (!formData.Price.trim()) {
      newErrors.Price = "Price is required";
    }
    if (!formData.Description.trim()) {
      newErrors.Description = "Description is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }
    setIsSubmitting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      const newProperty = {
        PropertyID: `P${String(Date.now()).slice(-3).padStart(3, '0')}`,
        ...formData,
        PropertyType: formData.PropertyType?.value,
        Status: formData.Status?.value,
        created_date: new Date().toISOString()
      };
      setShowSuccessModal(true);
    } catch (error) {
      console.error('Error creating property:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    router.push('/property');
  };

  const handleSuccessModalClose = () => {
    setShowSuccessModal(false);
    router.push('/property');
  };

  return (
    <div>
      <PageBreadcrumb crumbs={breadcrumbs} />
      
      <ComponentCard title="Create Property">
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Property Information Section */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-6">Property Information</h3>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <Address
                    value={formData.Location}
                    onSave={(address) => handleChange('Location', address)}
                    error={errors.Location}
                    label="Location *"
                  />
                </div>

                <div>
                  <Label htmlFor="PropertyName">Property Name *</Label>
                  <Input
                    id="PropertyName"
                    type="text"
                    value={formData.PropertyName}
                    onChange={(e) => handleChange('PropertyName', e.target.value)}
                    placeholder="Enter property name"
                    className={errors.PropertyName ? 'border-red-500' : ''}
                  />
                  {errors.PropertyName && (
                    <p className="mt-1 text-sm text-red-500">{errors.PropertyName}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="PropertyType">Property Type *</Label>
                  <Select
                    value={formData.PropertyType}
                    onChange={(value) => handleChange('PropertyType', value)}
                    options={propertyTypeOptions}
                    placeholder="Select Property Type"
                    className={errors.PropertyType ? 'border-red-500' : ''}
                  />
                  {errors.PropertyType && (
                    <p className="mt-1 text-sm text-red-500">{errors.PropertyType}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="Status">Status *</Label>
                  <Select
                    value={formData.Status}
                    onChange={(value) => handleChange('Status', value)}
                    options={statusOptions}
                    placeholder="Select Status"
                    className={errors.Status ? 'border-red-500' : ''}
                  />
                  {errors.Status && (
                    <p className="mt-1 text-sm text-red-500">{errors.Status}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="Price">Price *</Label>
                  <Input
                    id="Price"
                    type="text"
                    value={formData.Price}
                    onChange={(e) => handleChange('Price', e.target.value)}
                    placeholder="Enter price (e.g., $500,000)"
                    className={errors.Price ? 'border-red-500' : ''}
                  />
                  {errors.Price && (
                    <p className="mt-1 text-sm text-red-500">{errors.Price}</p>
                  )}
                </div>


                <div>
                  <Label htmlFor="Area">Area (sq ft)</Label>
                  <Input
                    id="Area"
                    type="text"
                    value={formData.Area}
                    onChange={(e) => handleChange('Area', e.target.value)}
                    placeholder="Enter area in square feet"
                    className={errors.Area ? 'border-red-500' : ''}
                  />
                  {errors.Area && (
                    <p className="mt-1 text-sm text-red-500">{errors.Area}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="Bedrooms">Bedrooms</Label>
                  <Input
                    id="Bedrooms"
                    type="number"
                    value={formData.Bedrooms}
                    onChange={(e) => handleChange('Bedrooms', e.target.value)}
                    placeholder="Number of bedrooms"
                    className={errors.Bedrooms ? 'border-red-500' : ''}
                  />
                  {errors.Bedrooms && (
                    <p className="mt-1 text-sm text-red-500">{errors.Bedrooms}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="Bathrooms">Bathrooms</Label>
                  <Input
                    id="Bathrooms"
                    type="number"
                    value={formData.Bathrooms}
                    onChange={(e) => handleChange('Bathrooms', e.target.value)}
                    placeholder="Number of bathrooms"
                    className={errors.Bathrooms ? 'border-red-500' : ''}
                  />
                  {errors.Bathrooms && (
                    <p className="mt-1 text-sm text-red-500">{errors.Bathrooms}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="YearBuilt">Year Built</Label>
                  <Input
                    id="YearBuilt"
                    type="number"
                    value={formData.YearBuilt}
                    onChange={(e) => handleChange('YearBuilt', e.target.value)}
                    placeholder="Year property was built"
                    className={errors.YearBuilt ? 'border-red-500' : ''}
                  />
                  {errors.YearBuilt && (
                    <p className="mt-1 text-sm text-red-500">{errors.YearBuilt}</p>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="Description">Description *</Label>
                <TextArea
                  value={formData.Description}
                  onChange={(value) => handleChange('Description', value)}
                  placeholder="Enter property description"
                  rows={4}
                  className={errors.Description ? 'border-red-500' : ''}
                />
                {errors.Description && (
                  <p className="mt-1 text-sm text-red-500">{errors.Description}</p>
                )}
              </div>

              <div>
                <Label htmlFor="Features">Features & Amenities</Label>
                <TextArea
                  value={formData.Features}
                  onChange={(value) => handleChange('Features', value)}
                  placeholder="Enter property features and amenities (e.g., Pool, Gym, Parking, etc.)"
                  rows={3}
                  className={errors.Features ? 'border-red-500' : ''}
                />
                {errors.Features && (
                  <p className="mt-1 text-sm text-red-500">{errors.Features}</p>
                )}
              </div>
            </div>
          </div>


          <div className="flex justify-end gap-4 pt-6 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Creating...' : 'Create Property'}
            </Button>
          </div>
        </form>
      </ComponentCard>

      {/* Success Modal */}
      <Modal isOpen={showSuccessModal} onClose={handleSuccessModalClose}>
        <div className="p-6 text-center">
          <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-green-100 rounded-full dark:bg-green-900/20">
            <svg className="w-6 h-6 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-900 dark:text-white">
            Property Created Successfully!
          </h3>
          <p className="mb-4 text-gray-600 dark:text-gray-400">
            The property has been added to the system.
          </p>
          <div className="flex justify-center space-x-4">
            <Button onClick={handleSuccessModalClose}>
              Back to Property List
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
