"use client";
import React, { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import ComponentCard from "@/components/common/ComponentCard";
import Button from "@/components/ui/button/Button";
import Label from "@/components/form/Label";
import Input from "@/components/form/input/InputField";
import TextArea from "@/components/form/input/TextArea";
import Select from "@/components/form/Select";
import { Modal } from "@/components/ui/modal";
import Address, { IAddress } from "@/components/form/Address";
import { propertiesData } from "@/components/form/sample-data/propertiesData";

const breadcrumbs = [
  { name: "Home", href: "/" },
  { name: "Property", href: "/property" },
  { name: "Edit", href: "/property/edit" }
];

interface ISelectOption {
  value: string;
  label: string;
}

interface FormData {
  PropertyName: string;
  Location: IAddress;
  PropertyType: ISelectOption | null;
  Status: ISelectOption | null;
  Price: string;
  Description: string;
  Features: string;
  Bedrooms: string;
  Bathrooms: string;
  Area: string;
  YearBuilt: string;
}

interface FormErrors {
  PropertyName?: string;
  Location?: string;
  PropertyType?: string;
  Price?: string;
  Status?: string;
  Description?: string;
  Features?: string;
  Bedrooms?: string;
  Bathrooms?: string;
  Area?: string;
  YearBuilt?: string;
}

export default function EditPropertyPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const propertyId = searchParams.get('id');

  // State for loading, not found, form data, errors, modal, and submitting
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    PropertyName: '',
    Location: {
      province: null,
      district: null,
      commune: null,
      village: null,
      homeAddress: '',
      streetAddress: '',
    },
    PropertyType: null,
    Status: null,
    Price: '',
    Description: '',
    Features: '',
    Bedrooms: '',
    Bathrooms: '',
    Area: '',
    YearBuilt: '',
  });
  const [formErrors, setFormErrors] = useState<FormErrors>({});
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Options for selects (could be fetched from API in real app)
  const propertyTypeOptions: ISelectOption[] = [
    { value: 'Apartment', label: 'Apartment' },
    { value: 'House', label: 'House' },
    { value: 'Condominium', label: 'Condominium' },
    { value: 'Villa', label: 'Villa' },
    { value: 'Lodge', label: 'Lodge' },
    { value: 'Penthouse', label: 'Penthouse' },
    { value: 'Cottage', label: 'Cottage' },
  ];
  const statusOptions: ISelectOption[] = [
    { value: "Available", label: "Available" },
    { value: "Reserved", label: "Reserved" },
    { value: "Sold", label: "Sold" },
    { value: "Under Construction", label: "Under Construction" },
    { value: "Maintenance", label: "Maintenance" },
  ];

  // Fetch property data on mount
  useEffect(() => {
    if (!propertyId) {
      setNotFound(true);
      setLoading(false);
      return;
    }
    // Simulate fetch
    const property = propertiesData.find((p) => p.PropertyID === propertyId);
    if (!property) {
      setNotFound(true);
      setLoading(false);
      return;
    }
    setFormData({
      PropertyName: property.PropertyName || '',
      Location: {
        province: null,
        district: null,
        commune: null,
        village: null,
        homeAddress: '',
        streetAddress: '',
      },
      PropertyType: propertyTypeOptions.find(opt => opt.value === property.PropertyType) || null,
      Status: statusOptions.find(opt => opt.value === property.Status) || null,
      Price: property.Price || '',
      Description: '',
      Features: '',
      Bedrooms: '',
      Bathrooms: '',
      Area: '',
      YearBuilt: '',
    });
    setLoading(false);
  }, [propertyId]);

  // Handlers
  const handleChange = (field: keyof FormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setFormErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleAddressSave = (value: IAddress) => {
    setFormData((prev) => ({ ...prev, Location: value }));
    setFormErrors((prev) => ({ ...prev, Location: undefined }));
  };

  const validate = (): boolean => {
    const errors: FormErrors = {};
    if (!formData.PropertyName) errors.PropertyName = 'Property name is required';
    if (!formData.Location || !formData.Location.province) errors.Location = 'Province is required';
    if (!formData.PropertyType) errors.PropertyType = 'Property type is required';
    if (!formData.Status) errors.Status = 'Status is required';
    if (!formData.Price) errors.Price = 'Price is required';
    if (!formData.Description) errors.Description = 'Description is required';
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsSubmitting(true);
    // Simulate API update
    setTimeout(() => {
      setIsSubmitting(false);
      setShowSuccessModal(true);
    }, 1200);
  };

  const handleCancel = () => {
    router.push('/property');
  };

  const handleSuccessModalClose = () => {
    setShowSuccessModal(false);
    router.push('/property');
  };

  // Render branches
  if (loading) {
    return (
      <div>
        <PageBreadcrumb crumbs={breadcrumbs} />
        <ComponentCard title="Edit Property">
          <div className="flex justify-center items-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span className="ml-2">Loading property data...</span>
          </div>
        </ComponentCard>
      </div>
    );
  }

  if (notFound) {
    return (
      <div>
        <PageBreadcrumb crumbs={breadcrumbs} />
        <ComponentCard title="Edit Property">
          <div className="text-center py-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Property Not Found</h3>
            <p className="text-gray-600 mb-4">The property you&apos;re looking for doesn&apos;t exist.</p>
            <Button onClick={handleCancel}>Back to Property List</Button>
          </div>
        </ComponentCard>
      </div>
    );
  }

  // Blue info card and form layout
  return (
    <div>
      <PageBreadcrumb crumbs={breadcrumbs} />
      <ComponentCard title="Edit Property">
        {/* Property Information Card */}
        <div className="mb-6 rounded-lg border border-blue-200 bg-blue-50 p-6 shadow-md dark:border-blue-900/30 dark:bg-blue-900/10 transition-colors">
          <div className="flex items-center justify-between border-b border-blue-100 pb-3 dark:border-blue-900/40">
            <div>
              <h3 className="text-base font-semibold text-blue-700 dark:text-blue-300 flex items-center gap-2">
                <svg className="w-5 h-5 text-blue-400" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" /></svg>
                Editing Property
              </h3>
              <p className="mt-1 text-sm text-blue-800 dark:text-blue-200">
                {formData.PropertyName || 'Unknown Property'}
              </p>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
              <dt className="text-xs font-medium text-body dark:text-bodydark">Property Name</dt>
              <dd className="mt-1 font-mono text-sm font-semibold text-black dark:text-white">
                {formData.PropertyName}
              </dd>
            </div>
            <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
              <dt className="text-xs font-medium text-body dark:text-bodydark">Type</dt>
              <dd className="mt-1 text-sm font-semibold text-black dark:text-white">
                {formData.PropertyType?.label || 'N/A'}
              </dd>
            </div>
          </div>
          <div className="mt-3 rounded-md bg-blue-50 p-2 dark:bg-blue-900/10">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-4 w-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-xs text-blue-800 dark:text-blue-200">
                  Review and update the property information below. Changes will be saved when you submit the form.
                </p>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-6">
            {/* Address Section - replicated from Project Edit page */}
            <div className="border-t pt-6 md:col-span-2">
              <Address
                value={formData.Location}
                onSave={handleAddressSave}
                error={formErrors.Location}
                label="Address Information *"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="PropertyName">Property Name *</Label>
                <Input
                  id="PropertyName"
                  value={formData.PropertyName}
                  onChange={e => handleChange('PropertyName', e.target.value)}
                  error={!!formErrors.PropertyName}
                  hint={formErrors.PropertyName}
                />
                {formErrors.PropertyName && (
                  <p className="mt-1 text-sm text-red-500">{formErrors.PropertyName}</p>
                )}
              </div>
              <div>
                <Label htmlFor="PropertyType">Property Type *</Label>
                <Select
                  options={propertyTypeOptions}
                  value={formData.PropertyType}
                  onChange={val => handleChange('PropertyType', val)}
                />
                {formErrors.PropertyType && <p className="text-sm text-red-500 mt-1">{formErrors.PropertyType}</p>}
              </div>
              <div>
                <Label htmlFor="Status">Status *</Label>
                <Select
                  value={formData.Status}
                  onChange={val => handleChange('Status', val)}
                  options={statusOptions}
                  placeholder="Select Status"
                  className={formErrors.Status ? 'border-red-500' : ''}
                />
                {formErrors.Status && (
                  <p className="mt-1 text-sm text-red-500">{formErrors.Status}</p>
                )}
              </div>
              <div>
                <Label htmlFor="Price">Price *</Label>
                <Input
                  id="Price"
                  value={formData.Price}
                  onChange={e => handleChange('Price', e.target.value)}
                  error={!!formErrors.Price}
                  hint={formErrors.Price}
                  type="text"
                />
                {formErrors.Price && (
                  <p className="mt-1 text-sm text-red-500">{formErrors.Price}</p>
                )}
              </div>
              <div>
                <Label htmlFor="Area">Area (sq ft)</Label>
                <Input
                  id="Area"
                  type="text"
                  value={formData.Area}
                  onChange={e => handleChange('Area', e.target.value)}
                  className={formErrors.Area ? 'border-red-500' : ''}
                />
                {formErrors.Area && (
                  <p className="mt-1 text-sm text-red-500">{formErrors.Area}</p>
                )}
              </div>
              <div>
                <Label htmlFor="Bedrooms">Bedrooms</Label>
                <Input
                  id="Bedrooms"
                  type="number"
                  value={formData.Bedrooms}
                  onChange={e => handleChange('Bedrooms', e.target.value)}
                  className={formErrors.Bedrooms ? 'border-red-500' : ''}
                />
                {formErrors.Bedrooms && (
                  <p className="mt-1 text-sm text-red-500">{formErrors.Bedrooms}</p>
                )}
              </div>
              <div>
                <Label htmlFor="Bathrooms">Bathrooms</Label>
                <Input
                  id="Bathrooms"
                  type="number"
                  value={formData.Bathrooms}
                  onChange={e => handleChange('Bathrooms', e.target.value)}
                  className={formErrors.Bathrooms ? 'border-red-500' : ''}
                />
                {formErrors.Bathrooms && (
                  <p className="mt-1 text-sm text-red-500">{formErrors.Bathrooms}</p>
                )}
              </div>
              <div>
                <Label htmlFor="YearBuilt">Year Built</Label>
                <Input
                  id="YearBuilt"
                  type="number"
                  value={formData.YearBuilt}
                  onChange={e => handleChange('YearBuilt', e.target.value)}
                  placeholder="Year property was built"
                  className={formErrors.YearBuilt ? 'border-red-500' : ''}
                />
                {formErrors.YearBuilt && (
                  <p className="mt-1 text-sm text-red-500">{formErrors.YearBuilt}</p>
                )}
              </div>
            </div>
            <div>
              <Label htmlFor="Description">Description *</Label>
              <TextArea
                value={formData.Description}
                onChange={value => handleChange('Description', value)}
                placeholder="Enter property description"
                rows={4}
                className={formErrors.Description ? 'border-red-500' : ''}
              />
              {formErrors.Description && (
                <p className="mt-1 text-sm text-red-500">{formErrors.Description}</p>
              )}
            </div>
            <div>
              <Label htmlFor="Features">Features & Amenities</Label>
              <TextArea
                value={formData.Features}
                onChange={value => handleChange('Features', value)}
                placeholder="Enter property features and amenities (e.g., Pool, Gym, Parking, etc.)"
                rows={3}
                className={formErrors.Features ? 'border-red-500' : ''}
              />
              {formErrors.Features && (
                <p className="mt-1 text-sm text-red-500">{formErrors.Features}</p>
              )}
            </div>
          </div>
          <div className="flex justify-end space-x-4 pt-6 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Updating...' : 'Update Property'}
            </Button>
          </div>
        </form>
      </ComponentCard>

      {/* Success Modal */}
      <Modal isOpen={showSuccessModal} onClose={handleSuccessModalClose}>
        <div className="p-6 text-center">
          <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-green-100 rounded-full dark:bg-green-900/20">
            <svg className="w-6 h-6 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-900 dark:text-white">
            Property Updated Successfully!
          </h3>
          <p className="mb-4 text-gray-600 dark:text-gray-400">
            The property has been updated in the system.
          </p>
          <div className="flex justify-center space-x-4">
            <Button onClick={handleSuccessModalClose}>
              Back to Property List
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
