"use client";
import React, { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import ComponentCard from "@/components/common/ComponentCard";
import Button from "@/components/ui/button/Button";
import Label from "@/components/form/Label";
import Select from "@/components/form/Select";
import DatePicker from "@/components/form/date-picker";
import TextArea from "@/components/form/input/TextArea";
import InputField from "@/components/form/input/InputField";
import { TimeIcon } from "@/icons";
import { ChevronLeftIcon, ChevronRightIcon, EyeIcon, PencilIcon, TrashIcon, EllipsisHorizontalIcon } from "@heroicons/react/24/outline";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import Badge from "@/components/ui/badge/Badge";
import { Modal } from "@/components/ui/modal";
import { callLogHistoryData } from "@/components/tables/sample-data/callLogHistoryData";
import { callLogsData } from "@/components/tables/sample-data/callLogsData";

interface SelectOption {
  value: string;
  label: string;
}

interface PipelineInfo {
  pipelineId: string;
  pipelineName: string;
  leadName: string;
  leadCompany: string;
  propertyName: string;
  propertyLocation: string;
  callerName: string;
  callerPhone: string;
}

interface CallLogEntry {
  callPipelineID: number;
  callLogOrderID: number;
  callDate: string;
  callStartTime: string;
  callEndTime: string;
  callStatus: string;
  notes: string;
  createdAt: string;
}

export default function QuickCallPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const pipelineId = searchParams.get('pipelineId') || '';

  const breadcrumbs = [
    { name: "Home", href: "/" },
    { name: "Call Pipeline", href: "/callpipeline" },
    { name: "Quick Call" },
  ];

  const [pipelineInfo, setPipelineInfo] = useState<PipelineInfo | null>(null);
  const [isLoadingPipeline, setIsLoadingPipeline] = useState(true);

  // Load pipeline information by ID
  useEffect(() => {
    const loadPipelineInfo = async () => {
      if (!pipelineId) {
        setIsLoadingPipeline(false);
        return;
      }

      try {
        // TODO: Replace with actual API call when backend is ready
        // const response = await api.get(`/pipeline/${pipelineId}`);
        // setPipelineInfo(response.data);
        
        // For now, get from sample data
        const pipeline = callLogsData.find(log => log.id.toString() === pipelineId);
        if (pipeline) {
          setPipelineInfo({
            pipelineId: pipeline.id.toString(),
            pipelineName: `${pipeline.lead.name} - ${pipeline.Property.name}`,
            leadName: pipeline.lead.name,
            leadCompany: pipeline.lead.company,
            propertyName: pipeline.Property.name,
            propertyLocation: pipeline.Property.Location,
            callerName: pipeline.caller.name,
            callerPhone: pipeline.caller.phone
          });
        }
      } catch (error) {
        console.error("Error loading pipeline information:", error);
      } finally {
        setIsLoadingPipeline(false);
      }
    };

    loadPipelineInfo();
  }, [pipelineId]);

  const [formData, setFormData] = useState({
    callDate: new Date(), // Use Date object for DatePicker
    callStartTime: "",
    callEndTime: "",
    callStatus: null as SelectOption | null,
    notes: "",
  });

  type CallLogFormErrors = {
    callDate?: string;
    callStartTime?: string;
    callEndTime?: string;
    callStatus?: string;
    notes?: string;
  };

  const [errors, setErrors] = useState<CallLogFormErrors>({});
  const [showAddCallModal, setShowAddCallModal] = useState(false);
  
  // Edit modal state
  const [showEditCallModal, setShowEditCallModal] = useState(false);
  const [editingCallLog, setEditingCallLog] = useState<CallLogEntry | null>(null);
  const [editFormData, setEditFormData] = useState({
    callDate: new Date(),
    callStartTime: "",
    callEndTime: "",
    callStatus: null as SelectOption | null,
    notes: "",
  });
  const [editErrors, setEditErrors] = useState<CallLogFormErrors>({});

  // View modal state
  const [showViewCallModal, setShowViewCallModal] = useState(false);
  const [viewingCallLog, setViewingCallLog] = useState<CallLogEntry | null>(null);

  // Call status options for Call Log History
  const statusOptions: SelectOption[] = [
    { value: "Completed", label: "Completed" },
    { value: "No Answer", label: "No Answer" },
    { value: "Busy", label: "Busy" },
    { value: "Voicemail", label: "Voicemail" },
    { value: "Cancelled", label: "Cancelled" },
    { value: "Failed", label: "Failed" },
  ];

  // Get call log history for this pipeline
  const pipelineCallHistory = pipelineInfo ? callLogHistoryData.filter(
    log => log.callPipelineID === parseInt(pipelineInfo.pipelineId || '0')
  ).sort((a, b) => b.callLogOrderID - a.callLogOrderID) : []; // Latest first

  const handleChange = (field: keyof typeof formData, value: string | SelectOption | null | Date) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prevErrors => {
        const newErrors = { ...prevErrors };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const validate = () => {
    const newErrors: CallLogFormErrors = {};
    
    if (!formData.callDate) newErrors.callDate = "Call date is required.";
    if (!formData.callStartTime) newErrors.callStartTime = "Start time is required.";
    if (!formData.callStatus) newErrors.callStatus = "Call status is required.";
    if (!formData.notes.trim()) newErrors.notes = "Notes are required.";
    
    // Validate end time is after start time if both are provided
    if (formData.callStartTime && formData.callEndTime) {
      const startTime = new Date(`2000-01-01T${formData.callStartTime}`);
      const endTime = new Date(`2000-01-01T${formData.callEndTime}`);
      if (endTime <= startTime) {
        newErrors.callEndTime = "End time must be after start time.";
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Form submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const resetForm = () => {
    setFormData({
      callDate: new Date(),
      callStartTime: "",
      callEndTime: "",
      callStatus: null,
      notes: "",
    });
    setErrors({});
    
    // Reset the date picker by destroying and recreating it
    setTimeout(() => {
      const datePickerElement = document.getElementById('call-date-picker') as HTMLInputElement;
      if (datePickerElement) {
        datePickerElement.value = '';
      }
    }, 0);
  };

  const handleSave = async () => { 
    if (!validate() || !pipelineInfo) return;
    
    try {
      setIsSubmitting(true);
      
      // Generate next order ID
      const nextOrderId = pipelineCallHistory.length > 0 
        ? Math.max(...pipelineCallHistory.map(log => log.callLogOrderID)) + 1 
        : 1;

      // Format date for API
      const callDate = formData.callDate instanceof Date 
        ? formData.callDate.toISOString().split('T')[0]
        : formData.callDate;
      
      const callLogData = {
        callPipelineID: parseInt(pipelineInfo.pipelineId),
        callLogOrderID: nextOrderId,
        callDate: callDate,
        callStartTime: formData.callStartTime,
        callEndTime: formData.callEndTime || "",
        callStatus: formData.callStatus?.value,
        notes: formData.notes,
        createdAt: new Date().toISOString(),
      };
      
      console.log("Quick Call Log Data to submit:", callLogData);
      
      // TODO: Replace with actual API call when backend is ready
      // await api.post('/call-log-history', callLogData);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Close the add call modal and reset form
      setShowAddCallModal(false);
      resetForm();
      
      // Show success modal
      setShowSuccessModal(true);
      
    } catch (error) {
      console.error("Error saving quick call log:", error);
      alert("Failed to save quick call log. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddAnother = () => {
    setShowSuccessModal(false);
    resetForm();
  };

  const handleCloseForm = () => {
    setShowSuccessModal(false);
    router.push("/callpipeline");
  };

  // Action handlers for call log history table
  const handleActionSelect = (action: 'view' | 'edit' | 'delete', callLog: CallLogEntry) => {
    switch (action) {
      case 'view':
        handleViewCallLog(callLog);
        break;
      case 'edit':
        handleEditCallLog(callLog);
        break;
      case 'delete':
        handleDeleteCallLog(callLog);
        break;
    }
  };

  const handleEditCallLog = (log: CallLogEntry) => {
    // Set the call log being edited
    setEditingCallLog(log);
    
    // Parse the date string back to Date object
    const callDate = new Date(log.callDate);
    
    // Find the matching status option
    const statusOption = statusOptions.find(option => option.value === log.callStatus);
    
    // Populate edit form with existing data
    setEditFormData({
      callDate: callDate,
      callStartTime: log.callStartTime,
      callEndTime: log.callEndTime,
      callStatus: statusOption || null,
      notes: log.notes,
    });
    
    // Clear any previous errors
    setEditErrors({});
    
    // Show the edit modal
    setShowEditCallModal(true);
    
    // Set the date picker value after modal opens
    setTimeout(() => {
      const editDatePickerElement = document.getElementById('edit-call-date-picker') as HTMLInputElement;
      if (editDatePickerElement) {
        // Format date as YYYY-MM-DD for the input
        const formattedDate = callDate.toISOString().split('T')[0];
        editDatePickerElement.value = formattedDate;
        
        // Trigger change event so Flatpickr updates
        const event = new Event('change', { bubbles: true });
        editDatePickerElement.dispatchEvent(event);
      }
    }, 100);
  };

  const handleViewCallLog = (log: CallLogEntry) => {
    setViewingCallLog(log);
    setShowViewCallModal(true);
  };

  const handleDeleteCallLog = (log: CallLogEntry) => {
    // TODO: Implement delete functionality with confirmation
    console.log("Delete call log:", log);
    const confirmed = confirm(`Are you sure you want to delete call log #${log.callLogOrderID}?\n\nThis action cannot be undone.`);
    if (confirmed) {
      alert(`Delete functionality for call log #${log.callLogOrderID} will be implemented soon.`);
    }
  };

  // Edit modal handlers
  const handleEditFormChange = (field: keyof typeof editFormData, value: string | SelectOption | null | Date) => {
    setEditFormData((prev) => ({ ...prev, [field]: value }));
    if (editErrors[field]) {
      setEditErrors(prevErrors => {
        const newErrors = { ...prevErrors };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const validateEditForm = () => {
    const newErrors: CallLogFormErrors = {};
    
    if (!editFormData.callDate) newErrors.callDate = "Call date is required.";
    if (!editFormData.callStartTime) newErrors.callStartTime = "Start time is required.";
    if (!editFormData.callStatus) newErrors.callStatus = "Call status is required.";
    if (!editFormData.notes.trim()) newErrors.notes = "Notes are required.";
    
    // Validate end time is after start time if both are provided
    if (editFormData.callStartTime && editFormData.callEndTime) {
      const startTime = new Date(`2000-01-01T${editFormData.callStartTime}`);
      const endTime = new Date(`2000-01-01T${editFormData.callEndTime}`);
      if (endTime <= startTime) {
        newErrors.callEndTime = "End time must be after start time.";
      }
    }
    
    setEditErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleEditSave = async () => {
    if (!validateEditForm() || !editingCallLog) return;
    
    try {
      setIsSubmitting(true);
      
      // Format date for API
      const callDate = editFormData.callDate instanceof Date 
        ? editFormData.callDate.toISOString().split('T')[0]
        : editFormData.callDate;
      
      const updatedCallLogData = {
        callPipelineID: editingCallLog.callPipelineID,
        callLogOrderID: editingCallLog.callLogOrderID,
        callDate: callDate,
        callStartTime: editFormData.callStartTime,
        callEndTime: editFormData.callEndTime || "",
        callStatus: editFormData.callStatus?.value,
        notes: editFormData.notes,
        createdAt: editingCallLog.createdAt, // Keep original created date
      };
      
      console.log("Updated Call Log Data to submit:", updatedCallLogData);
      
      // TODO: Replace with actual API call when backend is ready
      // await api.put(`/call-log-history/${editingCallLog.callLogOrderID}`, updatedCallLogData);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Close the edit modal and reset form
      setShowEditCallModal(false);
      resetEditForm();
      
      // Show success alert (could be replaced with a proper success modal)
      alert("Call log updated successfully!");
      
      // TODO: Refresh the call log history data to reflect changes
      // This would typically involve refetching the data or updating the local state
      
    } catch (error) {
      console.error("Error updating call log:", error);
      alert("Failed to update call log. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetEditForm = () => {
    setEditFormData({
      callDate: new Date(),
      callStartTime: "",
      callEndTime: "",
      callStatus: null,
      notes: "",
    });
    setEditErrors({});
    setEditingCallLog(null);
    
    // Reset the edit date picker by clearing its value
    setTimeout(() => {
      const editDatePickerElement = document.getElementById('edit-call-date-picker') as HTMLInputElement;
      if (editDatePickerElement) {
        editDatePickerElement.value = '';
      }
    }, 0);
  };

  const handleCancelEdit = () => {
    setShowEditCallModal(false);
    resetEditForm();
  };

  // Pagination state for call log history
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Calculate pagination for call log history
  const totalPages = Math.ceil(pipelineCallHistory.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentCallHistory = pipelineCallHistory.slice(startIndex, endIndex);

  // Pagination component - using the same design as CallLogsTable
  const Pagination = ({ currentPage, totalPages, onPageChange }: { currentPage: number, totalPages: number, onPageChange: (page: number) => void }) => {
    const getPageNumbers = () => {
      const pages = [];
      const pageLimit = 2;
      
      if (totalPages <= 1) return [];

      pages.push(1);

      if (currentPage > pageLimit + 1) {
        pages.push('...');
      }

      const startPage = Math.max(2, currentPage - pageLimit);
      const endPage = Math.min(totalPages - 1, currentPage + pageLimit);

      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }

      if (currentPage < totalPages - pageLimit - 1) {
        pages.push('...');
      }

      if (totalPages > 1) {
        pages.push(totalPages);
      }
      
      return [...new Set(pages)];
    };

    return (
      <nav className="flex items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => onPageChange(currentPage - 1)} disabled={currentPage === 1}>
          <ChevronLeftIcon className="h-4 w-4" />
        </Button>
        {getPageNumbers().map((page, index) =>
          typeof page === 'number' ? (
            <Button 
              key={index} 
              variant={currentPage === page ? 'primary' : 'outline'} 
              size="sm" 
              onClick={() => onPageChange(page)} 
              className="w-9"
            >
              {page}
            </Button>
          ) : (
            <span key={index} className="px-2 py-1 text-sm text-gray-500">...</span>
          )
        )}
        <Button variant="outline" size="sm" onClick={() => onPageChange(currentPage + 1)} disabled={currentPage === totalPages}>
          <ChevronRightIcon className="h-4 w-4" />
        </Button>
      </nav>
    );
  };

  // Format time for display
  const formatTime = (time: string) => {
    if (!time) return "N/A";
    return time;
  };

  // Calculate call duration
  const calculateDuration = (startTime: string, endTime: string) => {
    if (!startTime || !endTime) return "N/A";
    const start = new Date(`2000-01-01T${startTime}`);
    const end = new Date(`2000-01-01T${endTime}`);
    const diff = end.getTime() - start.getTime();
    const minutes = Math.floor(diff / 60000);
    return `${minutes}m`;
  };

  // Show loading or no data if pipeline info is not loaded
  if (isLoadingPipeline) {
    return (
      <div>
        <PageBreadcrumb crumbs={breadcrumbs} />
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500 mx-auto mb-4"></div>
            <p className="text-gray-500 dark:text-gray-400">Loading pipeline information...</p>
          </div>
        </div>
      </div>
    );
  }

  // Redirect to pipeline list if no pipelineId
  if (!pipelineId) {
    router.push("/callpipeline");
    return null;
  }

  if (!pipelineInfo) {
    return (
      <div>
        <PageBreadcrumb crumbs={breadcrumbs} />
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <p className="text-gray-500 dark:text-gray-400 mb-4">Pipeline not found.</p>
            <Button variant="outline" onClick={() => router.push("/callpipeline")}>
              Back to Call Pipeline
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageBreadcrumb crumbs={breadcrumbs} />
      <div className="space-y-6">
        {/* Section 1: General Information (Read-only) */}
        <ComponentCard title="Pipeline Information">
          <div className="mb-6 flex items-center justify-between">
            <h4 className="text-lg font-semibold text-gray-800 dark:text-white/90">
              General Information
            </h4>
            <div className="flex items-center space-x-3">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => router.back()}
                className="flex items-center gap-2"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Back
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => router.push(`/callpipeline/edit?id=${pipelineInfo.pipelineId}`)}
                className="flex items-center gap-2"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
                Edit
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  if (confirm('Are you sure you want to delete this call pipeline? This action cannot be undone.')) {
                    // TODO: Implement delete functionality
                    console.log('Delete pipeline:', pipelineInfo.pipelineId);
                    // router.push('/callpipeline');
                  }
                }}
                className="flex items-center gap-2 border-red-300 text-red-600 hover:bg-red-50 dark:border-red-600 dark:text-red-400 dark:hover:bg-red-900/10"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                Delete
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-4">
            <div>
              <p className="mb-2 text-xs leading-normal text-gray-500 dark:text-gray-400">
                Pipeline ID
              </p>
              <p className="text-sm font-medium text-gray-800 dark:text-white/90 font-mono">
                #{pipelineInfo.pipelineId}
              </p>
            </div>
            <div>
              <p className="mb-2 text-xs leading-normal text-gray-500 dark:text-gray-400">
                Lead Name
              </p>
              <p className="text-sm font-medium text-gray-800 dark:text-white/90">
                {pipelineInfo.leadName}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {pipelineInfo.leadCompany}
              </p>
            </div>
            <div>
              <p className="mb-2 text-xs leading-normal text-gray-500 dark:text-gray-400">
                Property Name
              </p>
              <p className="text-sm font-medium text-gray-800 dark:text-white/90">
                {pipelineInfo.propertyName}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {pipelineInfo.propertyLocation}
              </p>
            </div>
            <div>
              <p className="mb-2 text-xs leading-normal text-gray-500 dark:text-gray-400">
                Caller Information
              </p>
              <p className="text-sm font-medium text-gray-800 dark:text-white/90">
                {pipelineInfo.callerName}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {pipelineInfo.callerPhone}
              </p>
            </div>
          </div>
        </ComponentCard>

        {/* View Call Log Modal */}
        <Modal
          isOpen={showViewCallModal}
          onClose={() => setShowViewCallModal(false)}
          className="max-w-2xl p-4 lg:p-8"
        >
          <div className="px-2 lg:pr-10">
            <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">
              Call Log Entry Details
            </h4>
            <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
              Viewing details for Call Log #{viewingCallLog?.callLogOrderID || 'Unknown'}
            </p>
          </div>
          <div className="mb-6 rounded-sm border border-stroke bg-white p-4 shadow-default dark:border-strokedark dark:bg-boxdark">
            <div className="flex items-center justify-between border-b border-stroke pb-3 dark:border-strokedark">
              <div>
                <h3 className="text-base font-semibold text-black dark:text-white">
                  Call Log Information
                </h3>
                <p className="mt-1 text-sm text-body dark:text-bodydark">
                  Call Log #{viewingCallLog?.callLogOrderID || 'Unknown'}
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                  viewingCallLog?.callStatus === 'Completed'
                    ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300'
                    : viewingCallLog?.callStatus === 'Pending'
                    ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300'
                    : 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300'
                }`}>
                  {viewingCallLog?.callStatus || 'Unknown'}
                </span>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
                <dt className="text-xs font-medium text-body dark:text-bodydark">Call Log ID</dt>
                <dd className="mt-1 font-mono text-sm font-semibold text-black dark:text-white">
                  #{viewingCallLog?.callLogOrderID || 'N/A'}
                </dd>
              </div>
              <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
                <dt className="text-xs font-medium text-body dark:text-bodydark">Created Date</dt>
                <dd className="mt-1 text-sm font-semibold text-black dark:text-white">
                  {viewingCallLog?.createdAt || 'Not available'}
                </dd>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
                <dt className="text-xs font-medium text-body dark:text-bodydark">Call Date</dt>
                <dd className="mt-1 text-sm font-semibold text-black dark:text-white">
                  {viewingCallLog?.callDate || 'N/A'}
                </dd>
              </div>
              <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
                <dt className="text-xs font-medium text-body dark:text-bodydark">Start Time</dt>
                <dd className="mt-1 text-sm font-semibold text-black dark:text-white">
                  {viewingCallLog?.callStartTime || 'N/A'}
                </dd>
              </div>
              <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
                <dt className="text-xs font-medium text-body dark:text-bodydark">End Time</dt>
                <dd className="mt-1 text-sm font-semibold text-black dark:text-white">
                  {viewingCallLog?.callEndTime || 'N/A'}
                </dd>
              </div>
              <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
                <dt className="text-xs font-medium text-body dark:text-bodydark">Duration</dt>
                <dd className="mt-1 text-sm font-semibold text-black dark:text-white">
                  {viewingCallLog ? calculateDuration(viewingCallLog.callStartTime, viewingCallLog.callEndTime) : 'N/A'}
                </dd>
              </div>
            </div>
            <div className="mt-3 rounded-md bg-gray-1 p-3 dark:bg-meta-4">
              <dt className="text-xs font-medium text-body dark:text-bodydark">Notes</dt>
              <dd className="mt-1 text-sm font-semibold text-black dark:text-white">
                {viewingCallLog?.notes || 'N/A'}
              </dd>
            </div>
          </div>
          <div className="flex justify-end gap-3 mt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowViewCallModal(false)}
            >
              Close
            </Button>
          </div>
        </Modal>

        {/* Section 2: Add Call Log Button */}
        <div className="rounded-sm border border-stroke bg-white p-4 shadow-default dark:border-strokedark dark:bg-boxdark">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary bg-opacity-10">
                <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-black dark:text-white">
                  Quick Call Entry
                </h3>
                <p className="text-xs text-body dark:text-bodydark">
                  Add a new call log for this pipeline
                </p>
              </div>
            </div>
            <Button
              type="button"
              variant="primary"
              size="sm"
              onClick={() => setShowAddCallModal(true)}
              className="flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              Add Call
            </Button>
          </div>
        </div>

        {/* Section 3: Call Log History Table */}
        <div className="space-y-4">
          {/* Table Header with Title */}
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
                Call Log History for Pipeline #{pipelineInfo.pipelineId}
              </h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Total {pipelineCallHistory.length} call log {pipelineCallHistory.length === 1 ? 'entry' : 'entries'}
              </p>
            </div>
          </div>

          {pipelineCallHistory.length === 0 ? (
            <div className="py-8 text-center bg-white dark:bg-white/[0.03] rounded-xl border border-gray-200 dark:border-white/[0.05]">
              <p className="text-gray-500 dark:text-gray-400">
                No call history found for this pipeline. Add the first call log entry above.
              </p>
            </div>
          ) : (
            <>
              {/* Table */}
              <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
                <div className="max-w-full overflow-x-auto">
                  <div className="min-w-[900px]">
                    <Table>
                      <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
                        <TableRow>
                          <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">
                            #
                          </TableCell>
                          <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                            Date & Time
                          </TableCell>
                          <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                            Duration
                          </TableCell>
                          <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                            Status
                          </TableCell>
                          <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                            Notes
                          </TableCell>
                          <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                            Actions
                          </TableCell>
                        </TableRow>
                      </TableHeader>
                      <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
                        {currentCallHistory.map((log) => (
                          <TableRow key={`${log.callPipelineID}-${log.callLogOrderID}`}>
                            <TableCell className="px-5 py-4 text-center">
                              <span className="font-mono text-sm text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                                {log.callLogOrderID}
                              </span>
                            </TableCell>
                            <TableCell className="px-5 py-4">
                              <div>
                                <div className="font-medium text-gray-800 dark:text-white text-sm">
                                  {log.callDate}
                                </div>
                                <div className="text-gray-500 dark:text-gray-400 text-xs">
                                  {formatTime(log.callStartTime)} - {formatTime(log.callEndTime)}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell className="px-5 py-4 text-gray-500 text-sm dark:text-gray-400">
                              {calculateDuration(log.callStartTime, log.callEndTime)}
                            </TableCell>
                            <TableCell className="px-5 py-4">
                              <Badge
                                size="sm"
                                color={
                                  log.callStatus === "Completed"
                                    ? "success"
                                    : log.callStatus === "No Answer" || log.callStatus === "Failed"
                                    ? "error"
                                    : log.callStatus === "Busy" || log.callStatus === "Voicemail"
                                    ? "warning"
                                    : "info"
                                }
                              >
                                {log.callStatus}
                              </Badge>
                            </TableCell>
                            <TableCell className="px-5 py-4">
                              <div className="max-w-md text-sm text-gray-600 dark:text-gray-300">
                                {log.notes}
                              </div>
                            </TableCell>
                            <TableCell className="px-4 py-3 text-start">
                              <ActionMenu callLog={log} onSelect={handleActionSelect} />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>

              {/* Pagination - Using the same design as CallLogsTable */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between px-4 py-3">
                  <div className="flex items-center">
                    <span className="text-sm text-gray-700 dark:text-gray-300">
                      Showing{" "}
                      <span className="font-medium">{startIndex + 1}</span>
                      {" "}to{" "}
                      <span className="font-medium">
                        {Math.min(endIndex, pipelineCallHistory.length)}
                      </span>
                      {" "}of{" "}
                      <span className="font-medium">{pipelineCallHistory.length}</span>
                      {" "}entries
                    </span>
                  </div>
                  <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Add Call Log Modal */}
      <Modal 
        isOpen={showAddCallModal} 
        onClose={() => setShowAddCallModal(false)}
        className="max-w-4xl p-4 lg:p-11"
      >
        <div className="px-2 lg:pr-14">
          <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">
            Add Call Log Entry
          </h4>
          <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
            Fill in the details for this call log entry for Pipeline #{pipelineInfo.pipelineId}
          </p>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-4">
            
            {/* Call Date */}
            <div>
              <DatePicker
                id="call-date-picker"
                label="Call Date *"
                placeholder="Select call date"
                defaultDate={formData.callDate}
                onChange={(selectedDates) => {
                  if (selectedDates && selectedDates.length > 0) {
                    handleChange('callDate', selectedDates[0]);
                  }
                }}
              />
              {errors.callDate && <p className="text-sm text-red-500 mt-1">{errors.callDate}</p>}
            </div>

            {/* Call Start Time */}
            <div>
              <Label htmlFor="callStartTime">Start Time *</Label>
              <div className="relative">
                <InputField
                  type="time"
                  id="callStartTime"
                  value={formData.callStartTime}
                  onChange={(e) => handleChange('callStartTime', e.target.value)}
                  error={!!errors.callStartTime}
                />
                <span className="absolute text-gray-500 -translate-y-1/2 pointer-events-none right-3 top-1/2 dark:text-gray-400">
                  <TimeIcon />
                </span>
              </div>
              {errors.callStartTime && <p className="text-sm text-red-500 mt-1">{errors.callStartTime}</p>}
            </div>

            {/* Call End Time */}
            <div>
              <Label htmlFor="callEndTime">End Time</Label>
              <div className="relative">
                <InputField
                  type="time"
                  id="callEndTime"
                  value={formData.callEndTime}
                  onChange={(e) => handleChange('callEndTime', e.target.value)}
                  error={!!errors.callEndTime}
                />
                <span className="absolute text-gray-500 -translate-y-1/2 pointer-events-none right-3 top-1/2 dark:text-gray-400">
                  <TimeIcon />
                </span>
              </div>
              {errors.callEndTime && <p className="text-sm text-red-500 mt-1">{errors.callEndTime}</p>}
            </div>

            {/* Call Status */}
            <div>
              <Label htmlFor="callStatus">Call Status *</Label>
              <Select
                placeholder="Select status"
                options={statusOptions}
                value={formData.callStatus}
                onChange={(option) => handleChange('callStatus', option)}
              />
              {errors.callStatus && <p className="text-sm text-red-500 mt-1">{errors.callStatus}</p>}
            </div>
          </div>

          {/* Notes - Full width */}
          <div>
            <Label htmlFor="notes">Call Notes *</Label>
            <TextArea
              placeholder="Enter detailed call notes..."
              value={formData.notes}
              onChange={(value) => handleChange("notes", value)}
              rows={4}
            />
            {errors.notes && <p className="text-sm text-red-500 mt-1">{errors.notes}</p>}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowAddCallModal(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="primary"
              onClick={handleSave}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Saving..." : "Add Call Log"}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Success Modal */}
      <Modal 
        isOpen={showSuccessModal} 
        onClose={() => setShowSuccessModal(false)}
        className="max-w-md p-6"
      >
        <div className="text-center">
          <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-green-100 rounded-full dark:bg-green-900/20">
            <svg className="w-6 h-6 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          
          <h3 className="mb-2 text-lg font-semibold text-gray-800 dark:text-white">
            Quick Call Log Added Successfully!
          </h3>
          
          <p className="mb-6 text-sm text-gray-500 dark:text-gray-400">
            The call log has been added to pipeline #{pipelineInfo.pipelineId}. What would you like to do next?
          </p>
          
          <div className="flex flex-col gap-3 sm:flex-row sm:gap-3">
            <Button
              variant="outline"
              onClick={handleAddAnother}
              className="flex-1"
            >
              Add Another Call Log
            </Button>
            <Button
              variant="primary"
              onClick={handleCloseForm}
              className="flex-1"
            >
              Close Form
            </Button>
          </div>
        </div>
      </Modal>

      {/* Edit Call Log Modal */}
      <Modal 
        isOpen={showEditCallModal} 
        onClose={() => setShowEditCallModal(false)}
        className="max-w-4xl p-4 lg:p-11"
      >
        <div className="px-2 lg:pr-14">
          <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">
            Edit Call Log Entry
          </h4>
          <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
            Update the details for this call log entry
          </p>
        </div>

        {/* Call Log Information Card */}
        <div className="mb-6 rounded-sm border border-stroke bg-white p-4 shadow-default dark:border-strokedark dark:bg-boxdark">
          <div className="flex items-center justify-between border-b border-stroke pb-3 dark:border-strokedark">
            <div>
              <h3 className="text-base font-semibold text-black dark:text-white">
                Editing Call Log Entry
              </h3>
              <p className="mt-1 text-sm text-body dark:text-bodydark">
                Call Log #{editingCallLog?.callLogOrderID || 'Unknown'}
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                editingCallLog?.callStatus === 'Completed'
                  ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300'
                  : editingCallLog?.callStatus === 'Pending'
                  ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300'
                  : 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300'
              }`}>
                {editingCallLog?.callStatus || 'Unknown'}
              </span>
            </div>
          </div>
          
          <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
              <dt className="text-xs font-medium text-body dark:text-bodydark">Call Log ID</dt>
              <dd className="mt-1 font-mono text-sm font-semibold text-black dark:text-white">
                #{editingCallLog?.callLogOrderID || 'N/A'}
              </dd>
            </div>
            <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
              <dt className="text-xs font-medium text-body dark:text-bodydark">Created Date</dt>
              <dd className="mt-1 text-sm font-semibold text-black dark:text-white">
                {editingCallLog?.createdAt || 'Not available'}
              </dd>
            </div>
          </div>
          
          <div className="mt-3 rounded-md bg-blue-50 p-2 dark:bg-blue-900/10">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-4 w-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-xs text-blue-800 dark:text-blue-200">
                  Review and update the call log information below. Changes will be saved when you submit the form.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-4">
            
            {/* Call Date */}
            <div>
              <DatePicker
                id="edit-call-date-picker"
                label="Call Date *"
                placeholder="Select call date"
                defaultDate={editFormData.callDate}
                onChange={(selectedDates) => {
                  if (selectedDates && selectedDates.length > 0) {
                    handleEditFormChange('callDate', selectedDates[0]);
                  }
                }}
              />
              {editErrors.callDate && <p className="text-sm text-red-500 mt-1">{editErrors.callDate}</p>}
            </div>

            {/* Call Start Time */}
            <div>
              <Label htmlFor="editCallStartTime">Start Time *</Label>
              <div className="relative">
                <InputField
                  type="time"
                  id="editCallStartTime"
                  value={editFormData.callStartTime}
                  onChange={(e) => handleEditFormChange('callStartTime', e.target.value)}
                  error={!!editErrors.callStartTime}
                />
                <span className="absolute text-gray-500 -translate-y-1/2 pointer-events-none right-3 top-1/2 dark:text-gray-400">
                  <TimeIcon />
                </span>
              </div>
              {editErrors.callStartTime && <p className="text-sm text-red-500 mt-1">{editErrors.callStartTime}</p>}
            </div>

            {/* Call End Time */}
            <div>
              <Label htmlFor="editCallEndTime">End Time</Label>
              <div className="relative">
                <InputField
                  type="time"
                  id="editCallEndTime"
                  value={editFormData.callEndTime}
                  onChange={(e) => handleEditFormChange('callEndTime', e.target.value)}
                  error={!!editErrors.callEndTime}
                />
                <span className="absolute text-gray-500 -translate-y-1/2 pointer-events-none right-3 top-1/2 dark:text-gray-400">
                  <TimeIcon />
                </span>
              </div>
              {editErrors.callEndTime && <p className="text-sm text-red-500 mt-1">{editErrors.callEndTime}</p>}
            </div>

            {/* Call Status */}
            <div>
              <Label htmlFor="editCallStatus">Call Status *</Label>
              <Select
                placeholder="Select status"
                options={statusOptions}
                value={editFormData.callStatus}
                onChange={(option) => handleEditFormChange('callStatus', option)}
              />
              {editErrors.callStatus && <p className="text-sm text-red-500 mt-1">{editErrors.callStatus}</p>}
            </div>
          </div>

          {/* Notes - Full width */}
          <div>
            <Label htmlFor="editNotes">Call Notes *</Label>
            <TextArea
              placeholder="Enter detailed call notes..."
              value={editFormData.notes}
              onChange={(value) => handleEditFormChange("notes", value)}
              rows={4}
            />
            {editErrors.notes && <p className="text-sm text-red-500 mt-1">{editErrors.notes}</p>}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={handleCancelEdit}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="primary"
              onClick={handleEditSave}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

// Action Menu Component for call log entries
const ActionMenu = ({ callLog, onSelect }: { 
  callLog: CallLogEntry; 
  onSelect: (action: 'view' | 'edit' | 'delete', callLog: CallLogEntry) => void; 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={menuRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)} 
        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-white/[0.05] transition-colors"
      >
        <EllipsisHorizontalIcon className="h-5 w-5 text-gray-500" />
      </button>
      {isOpen && (
        <div className="absolute right-0 mt-2 w-40 bg-white dark:bg-dark-800 border border-gray-200 dark:border-white/[0.05] rounded-lg shadow-lg z-10">
          <ul className="py-1">
            <li>
              <a 
                href="#" 
                onClick={(e) => { 
                  e.preventDefault(); 
                  onSelect('view', callLog); 
                  setIsOpen(false); 
                }} 
                className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-white/[0.05]"
              >
                <EyeIcon className="h-4 w-4"/> 
                View
              </a>
            </li>
            <li>
              <a 
                href="#" 
                onClick={(e) => { 
                  e.preventDefault(); 
                  onSelect('edit', callLog); 
                  setIsOpen(false); 
                }} 
                className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-white/[0.05]"
              >
                <PencilIcon className="h-4 w-4"/> 
                Edit
              </a>
            </li>
            <li><hr className="my-1 border-gray-200 dark:border-white/[0.05]" /></li>
            <li>
              <a 
                href="#" 
                onClick={(e) => { 
                  e.preventDefault(); 
                  onSelect('delete', callLog); 
                  setIsOpen(false); 
                }} 
                className="flex items-center gap-3 px-4 py-2 text-sm text-red-500 hover:bg-gray-100 dark:hover:bg-white/[0.05]"
              >
                <TrashIcon className="h-4 w-4"/> 
                Delete
              </a>
            </li>
          </ul>
        </div>
      )}
    </div>
  );
};
