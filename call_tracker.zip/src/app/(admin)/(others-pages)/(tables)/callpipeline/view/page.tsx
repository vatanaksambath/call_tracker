"use client";
import React, { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import ComponentCard from "@/components/common/ComponentCard";
import Button from "@/components/ui/button/Button";
import { Modal } from "@/components/ui/modal";
import { callLogsData } from "@/components/tables/sample-data/callLogsData";
import { callLogHistoryData } from "@/components/tables/sample-data/callLogHistoryData";
import { siteVisitHistoryData } from "@/components/tables/sample-data/siteVisitHistoryData";
import { UserGroupIcon } from "@heroicons/react/24/outline";

const breadcrumbs = [
  { name: "Home", href: "/" },
  { name: "Call Pipeline", href: "/callpipeline" },
  { name: "View", href: "/callpipeline/view" }
];

interface PipelineInfo {
  pipelineId: string;
  pipelineName: string;
  leadName: string;
  leadCompany: string;
  propertyName: string;
  propertyLocation: string;
  callerName: string;
  callerPhone: string;
  createdAt?: string;
  updatedAt?: string;
  status?: string;
}

export default function ViewCallPipelinePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const pipelineId = searchParams.get('id');

  // Place hooks at the top
  const [activeTab, setActiveTab] = useState<'quickcall' | 'sitevisit'>('quickcall');
  const [pipelineInfo, setPipelineInfo] = useState<PipelineInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [pipelineNotFound, setPipelineNotFound] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Load pipeline data
  useEffect(() => {
    if (pipelineId) {
      // Simulate loading pipeline data
      const foundPipeline = callLogsData.find(log => log.id.toString() === pipelineId);
      if (foundPipeline) {
        setPipelineInfo({
          pipelineId: foundPipeline.id.toString(),
          pipelineName: `${foundPipeline.lead.name} - ${foundPipeline.Property.name}`,
          leadName: foundPipeline.lead.name,
          leadCompany: foundPipeline.lead.company,
          propertyName: foundPipeline.Property.name,
          propertyLocation: foundPipeline.Property.Location,
          callerName: foundPipeline.caller.name,
          callerPhone: foundPipeline.caller.phone,
          createdAt: foundPipeline.register_date,
          updatedAt: (foundPipeline as any).updatedAt || '',
          status: foundPipeline.last_status || '',
        });
        setIsLoading(false);
      } else {
        setPipelineNotFound(true);
        setIsLoading(false);
      }
    } else {
      setPipelineNotFound(true);
      setIsLoading(false);
    }
  }, [pipelineId]);

  const handleEdit = () => {
    router.push(`/callpipeline/edit?id=${pipelineId}`);
  };

  const handleDelete = () => {
    setShowDeleteModal(true);
  };

  const confirmDelete = async () => {
    setIsDeleting(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('Deleting pipeline:', pipelineId);
      router.push('/callpipeline');
    } catch (error) {
      console.error('Error deleting pipeline:', error);
    } finally {
      setIsDeleting(false);
      setShowDeleteModal(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500 mx-auto mb-4"></div>
          <p className="text-gray-500 dark:text-gray-400">Loading pipeline information...</p>
        </div>
      </div>
    );
  }

  if (pipelineNotFound || !pipelineInfo) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <p className="text-gray-500 dark:text-gray-400 mb-4">Pipeline not found.</p>
          <Button variant="outline" onClick={() => router.push("/callpipeline")}>Back to Call Pipeline</Button>
        </div>
      </div>
    );
  }

  const quickCallLogs = callLogHistoryData.filter(log => log.callPipelineID === parseInt(pipelineInfo.pipelineId));
  const siteVisitLogs = siteVisitHistoryData.filter(log => log.visitPipelineID === parseInt(pipelineInfo.pipelineId));

  return (
    <div>
      <PageBreadcrumb crumbs={breadcrumbs} />
      <ComponentCard title="Pipeline Details">
        <div className="space-y-8">
          {/* Header with Action Buttons */}
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 dark:bg-blue-500/10">
                  <UserGroupIcon className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {pipelineInfo.pipelineName}
                </h1>
              </div>
              <div className="flex items-center gap-3">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${pipelineInfo.status === 'Closed Won' ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300' : pipelineInfo.status === 'Hot Lead' ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300'}`}>{pipelineInfo.status || 'Status Unknown'}</span>
                <span className="text-sm text-gray-500 dark:text-gray-400">ID: {pipelineInfo.pipelineId}</span>
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => router.back()}>
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Back
              </Button>
              <Button variant="outline" onClick={handleEdit}>
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
                Edit
              </Button>
              <Button variant="outline" onClick={handleDelete} className="text-red-600 border-red-300 hover:bg-red-50 hover:border-red-400 dark:text-red-400 dark:border-red-600 dark:hover:bg-red-900/10">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                Delete
              </Button>
            </div>
          </div>
          {/* Pipeline Information Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                  <UserGroupIcon className="h-5 w-5" />
                  Pipeline Information
                </h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Pipeline ID:</div>
                    <div className="col-span-2 text-sm text-gray-900 dark:text-white font-mono">{pipelineInfo.pipelineId}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Lead Name:</div>
                    <div className="col-span-2 text-sm text-gray-900 dark:text-white">{pipelineInfo.leadName}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Lead Company:</div>
                    <div className="col-span-2 text-sm text-gray-900 dark:text-white">{pipelineInfo.leadCompany}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Property Name:</div>
                    <div className="col-span-2 text-sm text-gray-900 dark:text-white">{pipelineInfo.propertyName}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Property Location:</div>
                    <div className="col-span-2 text-sm text-gray-900 dark:text-white">{pipelineInfo.propertyLocation}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Caller Name:</div>
                    <div className="col-span-2 text-sm text-gray-900 dark:text-white">{pipelineInfo.callerName}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Caller Phone:</div>
                    <div className="col-span-2 text-sm text-gray-900 dark:text-white">{pipelineInfo.callerPhone}</div>
                  </div>
                </div>
              </div>
            </div>
            {/* System Information */}
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">System Information</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Created Date:</div>
                    <div className="col-span-2 text-sm text-gray-900 dark:text-white">{pipelineInfo.createdAt || 'N/A'}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Updated Date:</div>
                    <div className="col-span-2 text-sm text-gray-900 dark:text-white">{pipelineInfo.updatedAt || 'Not updated yet'}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">Status:</div>
                    <div className="col-span-2">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${pipelineInfo.status === 'Closed Won' ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300' : pipelineInfo.status === 'Hot Lead' ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300'}`}>{pipelineInfo.status || 'Status Unknown'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </ComponentCard>

      {/* Multi-page summary for Quick Call and Site Visit */}
      <ComponentCard title="Pipeline Activity Summary" className="mt-8">
        <div className="mb-4 flex gap-2 border-b border-gray-200 dark:border-white/[0.05]">
          <button className={`px-4 py-2 text-sm font-medium focus:outline-none ${activeTab === 'quickcall' ? 'border-b-2 border-blue-600 text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-300'}`} onClick={() => setActiveTab('quickcall')}>Quick Call</button>
          <button className={`px-4 py-2 text-sm font-medium focus:outline-none ${activeTab === 'sitevisit' ? 'border-b-2 border-blue-600 text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-300'}`} onClick={() => setActiveTab('sitevisit')}>Site Visit</button>
        </div>
        {activeTab === 'quickcall' ? (
          <div>
            {quickCallLogs.length === 0 ? (
              <div className="py-8 text-center text-gray-500 dark:text-gray-400">No quick call logs found for this pipeline.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-white/[0.05]">
                  <thead className="bg-gray-50 dark:bg-white/[0.02]">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Time</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">End Time</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Notes</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-white/[0.01] divide-y divide-gray-100 dark:divide-white/[0.03]">
                    {quickCallLogs.map((log) => (
                      <tr key={log.callLogOrderID}>
                        <td className="px-4 py-2 font-mono text-xs text-gray-600 dark:text-gray-300">{log.callLogOrderID}</td>
                        <td className="px-4 py-2 text-sm">{log.callDate}</td>
                        <td className="px-4 py-2 text-sm">{log.callStartTime}</td>
                        <td className="px-4 py-2 text-sm">{log.callEndTime}</td>
                        <td className="px-4 py-2 text-sm">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${log.callStatus === 'Completed' ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300' : log.callStatus === 'No Answer' || log.callStatus === 'Failed' ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300'}`}>{log.callStatus}</span>
                        </td>
                        <td className="px-4 py-2 text-sm text-gray-700 dark:text-gray-200 max-w-xs truncate">{log.notes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ) : (
          <div>
            {siteVisitLogs.length === 0 ? (
              <div className="py-8 text-center text-gray-500 dark:text-gray-400">No site visit logs found for this pipeline.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-white/[0.05]">
                  <thead className="bg-gray-50 dark:bg-white/[0.02]">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Time</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">End Time</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Attendees</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Notes</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-white/[0.01] divide-y divide-gray-100 dark:divide-white/[0.03]">
                    {siteVisitLogs.map((log) => (
                      <tr key={log.visitLogOrderID}>
                        <td className="px-4 py-2 font-mono text-xs text-gray-600 dark:text-gray-300">{log.visitLogOrderID}</td>
                        <td className="px-4 py-2 text-sm">{log.visitDate}</td>
                        <td className="px-4 py-2 text-sm">{log.visitStartTime}</td>
                        <td className="px-4 py-2 text-sm">{log.visitEndTime}</td>
                        <td className="px-4 py-2 text-sm">{log.visitType}</td>
                        <td className="px-4 py-2 text-sm">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${log.visitStatus === 'Completed' ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300' : log.visitStatus === 'No Show' || log.visitStatus === 'Cancelled' ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300'}`}>{log.visitStatus}</span>
                        </td>
                        <td className="px-4 py-2 text-sm text-gray-700 dark:text-gray-200 max-w-xs truncate">{log.attendees}</td>
                        <td className="px-4 py-2 text-sm text-gray-700 dark:text-gray-200 max-w-xs truncate">{log.notes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </ComponentCard>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={showDeleteModal} onClose={() => setShowDeleteModal(false)} className="max-w-md p-6">
        <div className="text-center">
          <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-red-100 rounded-full dark:bg-red-900/20">
            <svg className="w-6 h-6 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-800 dark:text-white">Delete Pipeline</h3>
          <p className="mb-6 text-sm text-gray-500 dark:text-gray-400">Are you sure you want to delete this pipeline? This action cannot be undone.</p>
          <div className="flex flex-col gap-3 sm:flex-row sm:gap-3">
            <Button variant="outline" onClick={() => setShowDeleteModal(false)} className="flex-1">Cancel</Button>
            <Button variant="primary" onClick={confirmDelete} className="flex-1" disabled={isDeleting}>{isDeleting ? "Deleting..." : "Delete"}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
