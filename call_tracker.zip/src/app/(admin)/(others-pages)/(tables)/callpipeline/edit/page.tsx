"use client";
import React, { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import ComponentCard from "@/components/common/ComponentCard";
import Button from "@/components/ui/button/Button";
import Label from "@/components/form/Label";
import TextArea from "@/components/form/input/TextArea";
import { ChevronLeftIcon, ChevronRightIcon } from "@heroicons/react/24/outline";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Modal } from "@/components/ui/modal";

interface Lead {
  id: number;
  name: string;
  company: string;
  email: string;
  phone: string;
}

interface Staff {
  id: number;
  name: string;
  department: string;
  email: string;
  phone: string;
}

interface Property {
  id: number;
  name: string;
  location: string;
  type: string;
  price: string;
}

interface CallPipeline {
  id: number;
  leadId: number;
  staffId: number;
  propertyId: number;
  notes: string;
  status: string;
  createdAt: string;
  updatedAt?: string;
}

// Mock data - these would come from your backend APIs
const leadsData = [
  { id: 1, name: "Sarah Johnson", company: "Tech Solutions Inc.", email: "sarah@techsolutions.com", phone: "+1-555-0101" },
  { id: 2, name: "Michael Chen", company: "Global Innovations", email: "michael@globalinnov.com", phone: "+1-555-0102" },
  { id: 3, name: "Emma Rodriguez", company: "StartupTech", email: "emma@startuptech.com", phone: "+1-555-0103" },
  { id: 4, name: "David Wilson", company: "Enterprise Corp", email: "david@enterprise.com", phone: "+1-555-0104" },
  { id: 5, name: "Lisa Anderson", company: "Digital Solutions", email: "lisa@digitalsol.com", phone: "+1-555-0105" },
  { id: 6, name: "Robert Martinez", company: "Creative Agency", email: "robert@creativeagency.com", phone: "+1-555-0106" },
];

const staffData = [
  { id: 1, name: "John Smith", department: "Sales", email: "john@company.com", phone: "+1-555-0201" },
  { id: 2, name: "Alice Johnson", department: "Sales", email: "alice@company.com", phone: "+1-555-0202" },
  { id: 3, name: "Bob Wilson", department: "Marketing", email: "bob@company.com", phone: "+1-555-0203" },
  { id: 4, name: "Carol Brown", department: "Sales", email: "carol@company.com", phone: "+1-555-0204" },
  { id: 5, name: "Mike Davis", department: "Support", email: "mike@company.com", phone: "+1-555-0205" },
];

const propertiesData = [
  { id: 1, name: "Sunset Boulevard Apartments", location: "Los Angeles", type: "Residential", price: "$2,500/month" },
  { id: 2, name: "Downtown Office Complex", location: "New York", type: "Commercial", price: "$5,000/month" },
  { id: 3, name: "Riverside Condos", location: "Miami", type: "Residential", price: "$3,200/month" },
  { id: 4, name: "Mountain View Residences", location: "Seattle", type: "Residential", price: "$2,800/month" },
  { id: 5, name: "City Center Plaza", location: "Chicago", type: "Commercial", price: "$4,500/month" },
];

// Mock call pipeline data - this would come from your backend API
const mockCallPipelineData: CallPipeline[] = [
  {
    id: 1,
    leadId: 1,
    staffId: 2, 
    propertyId: 3,
    notes: "Initial contact made. Client interested in scheduling a visit to view the property.",
    status: "Active",
    createdAt: "2024-07-01T10:00:00Z",
    updatedAt: "2024-07-05T14:30:00Z"
  },
  {
    id: 2,
    leadId: 3,
    staffId: 1,
    propertyId: 1,
    notes: "Follow-up call scheduled for next week. Client requested more information about financing options.",
    status: "Pending",
    createdAt: "2024-07-02T09:15:00Z"
  },
  {
    id: 3,
    leadId: 2,
    staffId: 4,
    propertyId: 2,
    notes: "Property tour completed successfully. Client expressed strong interest and will provide decision by Friday.",
    status: "Active", 
    createdAt: "2024-07-03T11:45:00Z",
    updatedAt: "2024-07-06T16:20:00Z"
  }
];

export default function EditCallPipelinePage() {
  // Always show the call pipeline edit form
  return <CallPipelineEditForm />;
}

// Selection Modal Component for Leads, Staff, and Properties
function SelectionModal<T extends { id: number }>({ 
  isOpen, 
  onClose, 
  onSelect, 
  title, 
  data, 
  columns,
  searchPlaceholder 
}: {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (item: T) => void;
  title: string;
  data: T[];
  columns: { key: string; label: string }[];
  searchPlaceholder: string;
}) {
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const filteredData = data.filter((item) =>
    Object.values(item).some((value) =>
      String(value).toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentData = filteredData.slice(startIndex, endIndex);

  const handleSelect = (item: T) => {
    onSelect(item);
    onClose();
    setSearchTerm("");
    setCurrentPage(1);
  };

  const handleClose = () => {
    onClose();
    setSearchTerm("");
    setCurrentPage(1);
  };

  if (!isOpen) return null;

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={handleClose} 
      className="max-w-[900px] p-4 lg:p-11"
    >
      <div className="px-2 lg:pr-14">
        <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">
          {title}
        </h4>
        <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
          Choose an item from the list below.
        </p>
      </div>
      
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center mb-4">
        <form>
          <div className="relative">
            <button 
              type="button"
              className="absolute -translate-y-1/2 left-4 top-1/2"
            >
              <svg 
                className="fill-gray-500 dark:fill-gray-400" 
                width="20" 
                height="20" 
                viewBox="0 0 20 20" 
                fill="none" 
                xmlns="http://www.w3.org/2000/svg"
              >
                <path 
                  fillRule="evenodd" 
                  clipRule="evenodd" 
                  d="M3.04199 9.37381C3.04199 5.87712 5.87735 3.04218 9.37533 3.04218C12.8733 3.04218 15.7087 5.87712 15.7087 9.37381C15.7087 12.8705 12.8733 15.7055 9.37533 15.7055C5.87735 15.7055 3.04199 12.8705 3.04199 9.37381ZM9.37533 1.54218C5.04926 1.54218 1.54199 5.04835 1.54199 9.37381C1.54199 13.6993 5.04926 17.2055 9.37533 17.2055C11.2676 17.2055 13.0032 16.5346 14.3572 15.4178L17.1773 18.2381C17.4702 18.531 17.945 18.5311 18.2379 18.2382C18.5308 17.9453 18.5309 17.4704 18.238 17.1775L15.4182 14.3575C16.5367 13.0035 17.2087 11.2671 17.2087 9.37381C17.2087 5.04835 13.7014 1.54218 9.37533 1.54218Z" 
                  fill=""
                />
              </svg>
            </button>
            <input 
              type="text" 
              placeholder={searchPlaceholder} 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="dark:bg-dark-900 h-[42px] w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-[42px] pr-4 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800 xl:w-[300px]"
            />
          </div>
        </form>
      </div>
        
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03] min-h-[400px]">
        {filteredData.length === 0 ? (
          <div className="flex items-center justify-center h-[400px]">
            <p className="text-gray-500 dark:text-gray-400 text-center">
              No results found matching your search.
            </p>
          </div>
        ) : (
          <div className="max-w-full overflow-x-auto">
            <div className="min-w-[800px]">
              <Table>
                <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
                  <TableRow>
                    {columns.map((col) => (
                      <TableCell
                        key={col.key}
                        isHeader
                        className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                      >
                        {col.label}
                      </TableCell>
                    ))}
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400"
                    >
                      Action
                    </TableCell>
                  </TableRow>
                </TableHeader>
                
                <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
                  {currentData.map((item, index) => (
                    <TableRow 
                      key={index} 
                      className="hover:bg-gray-50 dark:hover:bg-white/[0.02] cursor-pointer"
                    >
                      {columns.map((col) => (
                        <TableCell 
                          key={col.key} 
                          className="px-5 py-2 text-gray-800 text-start text-theme-sm dark:text-white/90"
                        >
                          <div onClick={() => handleSelect(item)} className="w-full h-full">
                            {(item as Record<string, unknown>)[col.key] as string}
                          </div>
                        </TableCell>
                      ))}
                      <TableCell className="px-4 py-2 text-center">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSelect(item);
                          }}
                          className="flex items-center justify-center gap-2 rounded-full border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 mx-auto"
                        >
                          Select
                        </button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </div>
      
      {/* Pagination */}
      {filteredData.length > 0 && (
        <div className="flex items-center justify-between mt-6 px-6 py-4">
          {/* Results info */}
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Showing {Math.min((currentPage - 1) * itemsPerPage + 1, filteredData.length)} to {Math.min(currentPage * itemsPerPage, filteredData.length)} of {filteredData.length} results
          </p>

          {/* Pagination controls */}
          <div className="flex items-center space-x-2">
            {/* Previous button */}
            <button
              onClick={() => setCurrentPage(currentPage - 1)}
              disabled={currentPage === 1}
              className="flex items-center justify-center w-8 h-8 rounded-lg border border-gray-300 bg-white text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
            >
              <ChevronLeftIcon className="w-4 h-4" />
            </button>

            {/* Page numbers */}
            {(() => {
              const pages = [];
              
              // Always show first page
              if (totalPages > 0) {
                pages.push(
                  <button
                    key={1}
                    onClick={() => setCurrentPage(1)}
                    className={`flex items-center justify-center w-8 h-8 rounded-lg text-sm font-medium ${
                      currentPage === 1
                        ? "bg-brand-500 text-white"
                        : "border border-gray-300 bg-white text-gray-500 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
                    }`}
                  >
                    1
                  </button>
                );
              }

              // Show ellipsis if needed
              if (currentPage > 3 && totalPages > 5) {
                pages.push(
                  <span key="ellipsis1" className="text-gray-500 dark:text-gray-400">
                    ...
                  </span>
                );
              }

              // Show pages around current page
              const start = Math.max(2, currentPage - 1);
              const end = Math.min(totalPages - 1, currentPage + 1);
              
              for (let i = start; i <= end; i++) {
                if (i !== 1 && i !== totalPages) {
                  pages.push(
                    <button
                      key={i}
                      onClick={() => setCurrentPage(i)}
                      className={`flex items-center justify-center w-8 h-8 rounded-lg text-sm font-medium ${
                        currentPage === i
                          ? "bg-brand-500 text-white"
                          : "border border-gray-300 bg-white text-gray-500 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
                      }`}
                    >
                      {i}
                    </button>
                  );
                }
              }

              // Show ellipsis if needed
              if (currentPage < totalPages - 2 && totalPages > 5) {
                pages.push(
                  <span key="ellipsis2" className="text-gray-500 dark:text-gray-400">
                    ...
                  </span>
                );
              }

              // Always show last page if more than 1 page
              if (totalPages > 1) {
                pages.push(
                  <button
                    key={totalPages}
                    onClick={() => setCurrentPage(totalPages)}
                    className={`flex items-center justify-center w-8 h-8 rounded-lg text-sm font-medium ${
                      currentPage === totalPages
                        ? "bg-brand-500 text-white"
                        : "border border-gray-300 bg-white text-gray-500 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
                    }`}
                  >
                    {totalPages}
                  </button>
                );
              }

              return pages;
            })()}

            {/* Next button */}
            <button
              onClick={() => setCurrentPage(currentPage + 1)}
              disabled={currentPage >= totalPages}
              className="flex items-center justify-center w-8 h-8 rounded-lg border border-gray-300 bg-white text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
            >
              <ChevronRightIcon className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
}

// Call Pipeline Edit Form Component
function CallPipelineEditForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const pipelineId = searchParams.get('id') || '';
  
  const breadcrumbs = [
    { name: "Home", href: "/" },
    { name: "Call Pipeline", href: "/callpipeline" },
    { name: "Edit Pipeline" },
  ];

  const [formData, setFormData] = useState({
    selectedLead: null as Lead | null,
    selectedStaff: null as Staff | null,
    selectedProperty: null as Property | null,
    notes: "",
  });
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // Modal states
  const [showLeadModal, setShowLeadModal] = useState(false);
  const [showStaffModal, setShowStaffModal] = useState(false);
  const [showPropertyModal, setShowPropertyModal] = useState(false);

  // Load existing pipeline data
  useEffect(() => {
    const loadPipelineData = async () => {
      if (!pipelineId) {
        setIsLoading(false);
        return;
      }

      try {
        // TODO: Replace with actual API call when backend is ready
        // const response = await api.get(`/call-pipeline/${pipelineId}`);
        // const pipelineData = response.data;
        
        // For now, use mock data
        const pipelineData = mockCallPipelineData.find(p => p.id.toString() === pipelineId);
        
        if (pipelineData) {
          // Find related data
          const lead = leadsData.find(l => l.id === pipelineData.leadId);
          const staff = staffData.find(s => s.id === pipelineData.staffId);
          const property = propertiesData.find(p => p.id === pipelineData.propertyId);
          
          // Populate form with existing data
          setFormData({
            selectedLead: lead || null,
            selectedStaff: staff || null,
            selectedProperty: property || null,
            notes: pipelineData.notes,
          });
        }
      } catch (error) {
        console.error("Error loading pipeline data:", error);
        alert("Failed to load pipeline data. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    loadPipelineData();
  }, [pipelineId]);

  const handleChange = (field: keyof typeof formData, value: Lead | Staff | Property | string | null) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prevErrors => {
        const newErrors = { ...prevErrors };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const validate = () => {
    const newErrors: {[key: string]: string} = {};
    
    if (!formData.selectedLead) newErrors.selectedLead = "Lead selection is required.";
    if (!formData.selectedStaff) newErrors.selectedStaff = "Staff selection is required.";
    if (!formData.selectedProperty) newErrors.selectedProperty = "Property selection is required.";
    if (!formData.notes.trim()) newErrors.notes = "Notes are required.";
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;
    
    try {
      setIsSubmitting(true);
      
      const updateData = {
        leadId: formData.selectedLead?.id,
        staffId: formData.selectedStaff?.id,
        propertyId: formData.selectedProperty?.id,
        notes: formData.notes,
        updatedAt: new Date().toISOString(),
      };
      
      console.log("Pipeline Update Data to submit:", updateData);
      
      // TODO: Replace with actual API call when backend is ready
      // await api.put(`/call-pipeline/${pipelineId}`, updateData);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Show success modal instead of redirecting immediately
      setShowSuccessModal(true);
      
    } catch (error) {
      console.error("Error updating call pipeline:", error);
      alert("Failed to update call pipeline. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    router.push("/callpipeline");
  };

  const handleBackToPipeline = () => {
    setShowSuccessModal(false);
    router.push("/callpipeline");
  };

  const handleContinueEditing = () => {
    setShowSuccessModal(false);
  };

  // Redirect to pipeline list if no pipelineId
  if (!pipelineId) {
    router.push("/callpipeline");
    return null;
  }

  // Show loading state
  if (isLoading) {
    return (
      <div>
        <PageBreadcrumb crumbs={breadcrumbs} />
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500 mx-auto mb-4"></div>
            <p className="text-gray-500 dark:text-gray-400">Loading pipeline data...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageBreadcrumb crumbs={breadcrumbs} />
      <div className="space-y-6">
        
        {/* Call Pipeline Edit Form */}
        <ComponentCard title={`Edit Call Pipeline #${pipelineId}`}>
          {/* Call Pipeline Information Card */}
          <div className="mb-6 rounded-sm border border-stroke bg-white p-4 shadow-default dark:border-strokedark dark:bg-boxdark">
            <div className="flex items-center justify-between border-b border-stroke pb-3 dark:border-strokedark">
              <div>
                <h3 className="text-base font-semibold text-black dark:text-white">
                  Editing Call Pipeline
                </h3>
                <p className="mt-1 text-sm text-body dark:text-bodydark">
                  Pipeline #{pipelineId}
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300">
                  Active
                </span>
              </div>
            </div>
            
            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
                <dt className="text-xs font-medium text-body dark:text-bodydark">Pipeline ID</dt>
                <dd className="mt-1 font-mono text-sm font-semibold text-black dark:text-white">
                  #{pipelineId}
                </dd>
              </div>
              <div className="rounded-md bg-gray-1 p-3 dark:bg-meta-4">
                <dt className="text-xs font-medium text-body dark:text-bodydark">Created Date</dt>
                <dd className="mt-1 text-sm font-semibold text-black dark:text-white">
                  Not available
                </dd>
              </div>
            </div>
            
            <div className="mt-3 rounded-md bg-blue-50 p-2 dark:bg-blue-900/10">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-4 w-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-xs text-blue-800 dark:text-blue-200">
                    Review and update the call pipeline information below. Changes will be saved when you submit the form.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
            
            {/* Lead Selection */}
            <div>
              <Label htmlFor="selectedLead">Select Lead *</Label>
              <div className="mt-1">
                {formData.selectedLead ? (
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg border">
                    <div>
                      <div className="font-medium text-gray-800 dark:text-white">{formData.selectedLead.name}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">{formData.selectedLead.company}</div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowLeadModal(true)}
                    >
                      Change
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    onClick={() => setShowLeadModal(true)}
                    className="w-full justify-center"
                  >
                    Choose Lead
                  </Button>
                )}
              </div>
              {errors.selectedLead && <p className="text-sm text-red-500 mt-1">{errors.selectedLead}</p>}
            </div>

            {/* Staff Selection */}
            <div>
              <Label htmlFor="selectedStaff">Select Staff *</Label>
              <div className="mt-1">
                {formData.selectedStaff ? (
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg border">
                    <div>
                      <div className="font-medium text-gray-800 dark:text-white">{formData.selectedStaff.name}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">{formData.selectedStaff.department}</div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowStaffModal(true)}
                    >
                      Change
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    onClick={() => setShowStaffModal(true)}
                    className="w-full justify-center"
                  >
                    Choose Staff
                  </Button>
                )}
              </div>
              {errors.selectedStaff && <p className="text-sm text-red-500 mt-1">{errors.selectedStaff}</p>}
            </div>

            {/* Property Selection */}
            <div className="lg:col-span-2">
              <Label htmlFor="selectedProperty">Select Property *</Label>
              <div className="mt-1">
                {formData.selectedProperty ? (
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg border">
                    <div>
                      <div className="font-medium text-gray-800 dark:text-white">{formData.selectedProperty.name}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">{formData.selectedProperty.location} • {formData.selectedProperty.type}</div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowPropertyModal(true)}
                    >
                      Change
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    onClick={() => setShowPropertyModal(true)}
                    className="w-full justify-center"
                  >
                    Choose Property
                  </Button>
                )}
              </div>
              {errors.selectedProperty && <p className="text-sm text-red-500 mt-1">{errors.selectedProperty}</p>}
            </div>
          </div>

          {/* Notes - Full width */}
          <div className="mt-5">
            <Label htmlFor="notes">Notes *</Label>
            <TextArea
              placeholder="Enter call pipeline notes..."
              value={formData.notes}
              onChange={(value) => handleChange("notes", value)}
              rows={4}
            />
            {errors.notes && <p className="text-sm text-red-500 mt-1">{errors.notes}</p>}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 mt-6">
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="primary"
              onClick={handleSave}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Updating..." : "Update Pipeline"}
            </Button>
          </div>
        </ComponentCard>
      </div>

      {/* Selection Modals */}
      <SelectionModal
        isOpen={showLeadModal}
        onClose={() => setShowLeadModal(false)}
        onSelect={(lead) => handleChange('selectedLead', lead)}
        title="Select Lead"
        data={leadsData}
        columns={[
          { key: 'name', label: 'Name' },
          { key: 'company', label: 'Company' },
          { key: 'email', label: 'Email' },
          { key: 'phone', label: 'Phone' },
        ]}
        searchPlaceholder="Search leads..."
      />

      <SelectionModal
        isOpen={showStaffModal}
        onClose={() => setShowStaffModal(false)}
        onSelect={(staff) => handleChange('selectedStaff', staff)}
        title="Select Staff"
        data={staffData}
        columns={[
          { key: 'name', label: 'Name' },
          { key: 'department', label: 'Department' },
          { key: 'email', label: 'Email' },
          { key: 'phone', label: 'Phone' },
        ]}
        searchPlaceholder="Search staff..."
      />

      <SelectionModal
        isOpen={showPropertyModal}
        onClose={() => setShowPropertyModal(false)}
        onSelect={(property) => handleChange('selectedProperty', property)}
        title="Select Property"
        data={propertiesData}
        columns={[
          { key: 'name', label: 'Property Name' },
          { key: 'location', label: 'Location' },
          { key: 'type', label: 'Type' },
          { key: 'price', label: 'Price' },
        ]}
        searchPlaceholder="Search properties..."
      />

      {/* Success Modal */}
      <Modal 
        isOpen={showSuccessModal} 
        onClose={() => setShowSuccessModal(false)}
        className="max-w-md p-6"
      >
        <div className="text-center">
          <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-green-100 rounded-full dark:bg-green-900/20">
            <svg className="w-6 h-6 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          
          <h3 className="mb-2 text-lg font-semibold text-gray-800 dark:text-white">
            Call Pipeline Updated Successfully!
          </h3>
          
          <p className="mb-6 text-sm text-gray-500 dark:text-gray-400">
            Pipeline #{pipelineId} has been updated with your changes. What would you like to do next?
          </p>
          
          <div className="flex flex-col gap-3 sm:flex-row sm:gap-3">
            <Button
              variant="outline"
              onClick={handleContinueEditing}
              className="flex-1"
            >
              Continue Editing
            </Button>
            <Button
              variant="primary"
              onClick={handleBackToPipeline}
              className="flex-1"
            >
              Back to Pipeline List
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
