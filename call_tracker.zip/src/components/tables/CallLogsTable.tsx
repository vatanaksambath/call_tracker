"use client";
import React, { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";
import Badge from "../ui/badge/Badge";
import Image from "next/image";
import { 
    EyeIcon, PencilIcon, TrashIcon, EllipsisHorizontalIcon, AdjustmentsHorizontalIcon,
    ChevronLeftIcon, ChevronRightIcon, PlusIcon, PhoneIcon, MapPinIcon 
} from "@heroicons/react/24/outline";
import Button from "../ui/button/Button";
import { CallLog, callLogsData } from "./sample-data/callLogsData";

// Define available columns for the table
const allColumns: { key: keyof CallLog; label: string }[] = [
    { key: 'id', label: 'ID' },
    { key: 'caller', label: 'Caller' },
    { key: 'lead', label: 'Lead' },
    { key: 'Property', label: 'Property' },
    { key: 'number_of_call', label: 'Calls' },
    { key: 'number_of_site_visit', label: 'Site Visits' },
    { key: 'last_status', label: 'Last Status' },
    { key: 'last_status_date', label: 'Last Status Date' },
    { key: 'followUpRequired', label: 'Follow Up Required' },
    { key: 'followupDate', label: 'Follow Up Date' },
    { key: 'register_date', label: 'Register Date' },
];

const ActionMenu = ({ callLog, onSelect }: { callLog: CallLog; onSelect: (action: 'view' | 'edit' | 'delete' | 'quickCall' | 'siteVisit', callLog: CallLog) => void; }) => {
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) setIsOpen(false);
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    return (
        <div className="relative" ref={menuRef}>
            <button onClick={() => setIsOpen(!isOpen)} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-white/[0.05] transition-colors">
                <EllipsisHorizontalIcon className="h-5 w-5 text-gray-500" />
            </button>
            {isOpen && (
                <div className="absolute right-0 mt-2 w-40 bg-white dark:bg-dark-800 border border-gray-200 dark:border-white/[0.05] rounded-lg shadow-lg z-10">
                    <ul className="py-1">
                        <li><a href="#" onClick={(e) => { e.preventDefault(); onSelect('view', callLog); setIsOpen(false); }} className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-white/[0.05]"><EyeIcon className="h-4 w-4"/> View</a></li>
                        <li><a href="#" onClick={(e) => { e.preventDefault(); onSelect('edit', callLog); setIsOpen(false); }} className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-white/[0.05]"><PencilIcon className="h-4 w-4"/> Edit</a></li>
                        <li><hr className="my-1 border-gray-200 dark:border-white/[0.05]" /></li>
                        <li><a href="#" onClick={(e) => { e.preventDefault(); onSelect('quickCall', callLog); setIsOpen(false); }} className="flex items-center gap-3 px-4 py-2 text-sm text-blue-600 dark:text-blue-400 hover:bg-gray-100 dark:hover:bg-white/[0.05]"><PhoneIcon className="h-4 w-4"/> Quick Call</a></li>
                        <li><a href="#" onClick={(e) => { e.preventDefault(); onSelect('siteVisit', callLog); setIsOpen(false); }} className="flex items-center gap-3 px-4 py-2 text-sm text-green-600 dark:text-green-400 hover:bg-gray-100 dark:hover:bg-white/[0.05]"><MapPinIcon className="h-4 w-4"/> Site Visit</a></li>
                        <li><hr className="my-1 border-gray-200 dark:border-white/[0.05]" /></li>
                        <li><a href="#" onClick={(e) => { e.preventDefault(); onSelect('delete', callLog); setIsOpen(false); }} className="flex items-center gap-3 px-4 py-2 text-sm text-red-500 hover:bg-gray-100 dark:hover:bg-white/[0.05]"><TrashIcon className="h-4 w-4"/> Delete</a></li>
                    </ul>
                </div>
            )}
        </div>
    );
};

const ColumnSelector = ({ visibleColumns, setVisibleColumns }: { visibleColumns: (keyof CallLog)[], setVisibleColumns: React.Dispatch<React.SetStateAction<(keyof CallLog)[]>> }) => {
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    const toggleColumn = (columnKey: keyof CallLog) => {
        setVisibleColumns(prev => 
            prev.includes(columnKey) 
                ? prev.filter(key => key !== columnKey) 
                : [...prev, columnKey]
        );
    };

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) setIsOpen(false);
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    return (
        <div className="relative" ref={menuRef}>
            <Button variant="outline" size="sm" onClick={() => setIsOpen(!isOpen)} className="flex items-center gap-2">
                <AdjustmentsHorizontalIcon className="h-4 w-4" />
                Customize Columns
            </Button>
            {isOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-dark-800 border border-gray-200 dark:border-white/[0.05] rounded-lg shadow-lg z-10">
                    <div className="p-4">
                        <h4 className="font-semibold mb-2">Visible Columns</h4>
                        <div className="grid grid-cols-2 gap-2">
                            {allColumns.map(col => (
                                <label key={col.key} className="flex items-center gap-2 text-sm cursor-pointer">
                                    <input 
                                        type="checkbox" 
                                        checked={visibleColumns.includes(col.key)}
                                        onChange={() => toggleColumn(col.key)}
                                        className="form-checkbox h-4 w-4 rounded text-blue-600"
                                    />
                                    {col.label}
                                </label>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const Pagination = ({ currentPage, totalPages, onPageChange }: { currentPage: number, totalPages: number, onPageChange: (page: number) => void }) => {
    const getPageNumbers = () => {
        const pages = [];
        const pageLimit = 2;
        
        if (totalPages <= 1) return [];

        pages.push(1);

        if (currentPage > pageLimit + 1) {
            pages.push('...');
        }

        const startPage = Math.max(2, currentPage - pageLimit);
        const endPage = Math.min(totalPages - 1, currentPage + pageLimit);

        for (let i = startPage; i <= endPage; i++) {
            pages.push(i);
        }

        if (currentPage < totalPages - pageLimit -1) {
            pages.push('...');
        }

        if (totalPages > 1) {
            pages.push(totalPages);
        }
        
        return [...new Set(pages)];
    };

    return (
        <nav className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => onPageChange(currentPage - 1)} disabled={currentPage === 1}>
                <ChevronLeftIcon className="h-4 w-4" />
            </Button>
            {getPageNumbers().map((page, index) =>
                typeof page === 'number' ? (
                    <Button 
                        key={index} 
                        variant={currentPage === page ? 'primary' : 'outline'} 
                        size="sm" 
                        onClick={() => onPageChange(page)} 
                        className="w-9"
                    >
                        {page}
                    </Button>
                ) : (
                    <span key={index} className="px-2 py-1 text-sm text-gray-500">...</span>
                )
            )}
            <Button variant="outline" size="sm" onClick={() => onPageChange(currentPage + 1)} disabled={currentPage === totalPages}>
                <ChevronRightIcon className="h-4 w-4" />
            </Button>
        </nav>
    );
};

export default function CallLogsTable() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [visibleColumns, setVisibleColumns] = useState<(keyof CallLog)[]>([
    'id', 'caller', 'lead', 'Property', 'register_date', 'number_of_call', 'number_of_site_visit', 'last_status', 'last_status_date', 'followUpRequired', 'followupDate'
  ]);
  const itemsPerPage = 10;

  // Filter call logs based on search term
  const filteredCallLogs = callLogsData.filter(
    (callLog: CallLog) =>
      callLog.id.toString().includes(searchTerm) ||
      callLog.caller.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      callLog.lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      callLog.lead.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      callLog.Property.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      callLog.Property.Location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      callLog.caller.phone.includes(searchTerm) ||
      callLog.last_status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Calculate pagination
  const totalPages = Math.ceil(filteredCallLogs.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentCallLogs = filteredCallLogs.slice(startIndex, endIndex);

  const handleEdit = (id: number) => {
    console.log("Edit call log:", id);
    // Navigate to edit page with call pipeline ID
    router.push(`/callpipeline/edit?id=${id}`);
  };

  const handleDelete = (id: number) => {
    console.log("Delete call log:", id);
    // TODO: Implement delete functionality
  };

  const handleView = (id: number) => {
    router.push(`/callpipeline/view?id=${id}`);
  };

  const handleQuickCall = (callLog: CallLog) => {
    // Navigate to dedicated quick call page with only pipeline ID
    // The page will fetch pipeline details from the backend API
    router.push(`/callpipeline/quickcall?pipelineId=${callLog.id}`);
  };

  const handleSiteVisit = (callLog: CallLog) => {
    // Navigate to site visit page with pipeline ID
    router.push(`/callpipeline/sitevisit?pipelineId=${callLog.id}`);
  };

  const handleActionSelect = (action: 'view' | 'edit' | 'delete' | 'quickCall' | 'siteVisit', callLog: CallLog) => {
    switch (action) {
      case 'view':
        handleView(callLog.id);
        break;
      case 'edit':
        handleEdit(callLog.id);
        break;
      case 'delete':
        handleDelete(callLog.id);
        break;
      case 'quickCall':
        handleQuickCall(callLog);
        break;
      case 'siteVisit':
        handleSiteVisit(callLog);
        break;
    }
  };

  const handleAddCallLog = () => {
    router.push("/callpipeline/create");
  };

  return (
    <div className="space-y-4">
      {/* Search Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4 flex-1">
          <Button 
            variant="primary" 
            size="sm" 
            onClick={handleAddCallLog}
            className="flex items-center gap-2 whitespace-nowrap"
          >
            <PlusIcon className="h-4 w-4" />
            Add Call Pipeline
          </Button>
          <div className="flex-1 max-w-md">
            <div className="relative">
              <span className="absolute -translate-y-1/2 left-4 top-1/2 pointer-events-none">
                <svg
                  className="fill-gray-500 dark:fill-gray-400"
                  width="20"
                  height="20"
                  viewBox="0 0 20 20"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M3.04175 9.37363C3.04175 5.87693 5.87711 3.04199 9.37508 3.04199C12.8731 3.04199 15.7084 5.87693 15.7084 9.37363C15.7084 12.8703 12.8731 15.7053 9.37508 15.7053C5.87711 15.7053 3.04175 12.8703 3.04175 9.37363ZM9.37508 1.54199C5.04902 1.54199 1.54175 5.04817 1.54175 9.37363C1.54175 13.6991 5.04902 17.2053 9.37508 17.2053C11.2674 17.2053 13.003 16.5344 14.357 15.4176L17.177 18.238C17.4699 18.5309 17.9448 18.5309 18.2377 18.238C18.5306 17.9451 18.5306 17.4703 18.2377 17.1774L15.418 14.3573C16.5365 13.0033 17.2084 11.2669 17.2084 9.37363C17.2084 5.04817 13.7011 1.54199 9.37508 1.54199Z"
                    fill=""
                  />
                </svg>
              </span>
              <input
                type="text"
                placeholder="Search call pipeline..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="h-11 w-full rounded-lg border border-gray-200 bg-transparent py-2.5 pl-12 pr-4 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-800 dark:bg-white/[0.03] dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
              />
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <ColumnSelector visibleColumns={visibleColumns} setVisibleColumns={setVisibleColumns} />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
        <div className="max-w-full overflow-x-auto">
          <div className="min-w-[1200px]">
            <Table>
              {/* Table Header */}
              <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
                <TableRow>
                  {visibleColumns.includes('id') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      ID
                    </TableCell>
                  )}
                  {visibleColumns.includes('caller') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      Caller
                    </TableCell>
                  )}
                  {visibleColumns.includes('lead') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      Lead
                    </TableCell>
                  )}
                  {visibleColumns.includes('Property') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      Property
                    </TableCell>
                  )}
                  {visibleColumns.includes('number_of_call') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      Calls
                    </TableCell>
                  )}
                  {visibleColumns.includes('number_of_site_visit') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      Site Visits
                    </TableCell>
                  )}
                  {visibleColumns.includes('last_status') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      Last Status
                    </TableCell>
                  )}
                  {visibleColumns.includes('last_status_date') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      Last Status Date
                    </TableCell>
                  )}
                  {visibleColumns.includes('followUpRequired') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      Follow Up Required
                    </TableCell>
                  )}
                  {visibleColumns.includes('followupDate') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      Follow Up Date
                    </TableCell>
                  )}
                  {visibleColumns.includes('register_date') && (
                    <TableCell
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                    >
                      Register Date
                    </TableCell>
                  )}
                  <TableCell
                    isHeader
                    className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                  >
                    Actions
                  </TableCell>
                </TableRow>
              </TableHeader>

              {/* Table Body */}
              <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
                {currentCallLogs.map((callLog: CallLog) => (
                  <TableRow key={callLog.id}>
                    {visibleColumns.includes('id') && (
                      <TableCell className="px-5 py-4 sm:px-6 text-start">
                        <span className="font-mono text-sm text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                          {callLog.id}
                        </span>
                      </TableCell>
                    )}
                    {visibleColumns.includes('caller') && (
                      <TableCell className="px-5 py-4 sm:px-6 text-start">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 overflow-hidden rounded-full">
                            <Image
                              width={40}
                              height={40}
                              src={callLog.caller.image}
                              alt={callLog.caller.name}
                            />
                          </div>
                          <div>
                            <span className="block font-medium text-gray-800 text-theme-sm dark:text-white/90">
                              {callLog.caller.name}
                            </span>
                            <span className="block text-gray-500 text-theme-xs dark:text-gray-400">
                              {callLog.caller.phone}
                            </span>
                          </div>
                        </div>
                      </TableCell>
                    )}
                    {visibleColumns.includes('lead') && (
                      <TableCell className="px-4 py-3 text-start">
                        <div>
                          <span className="block font-medium text-gray-800 text-theme-sm dark:text-white/90">
                            {callLog.lead.name}
                          </span>
                          <span className="block text-gray-500 text-theme-xs dark:text-gray-400">
                            {callLog.lead.company}
                          </span>
                        </div>
                      </TableCell>
                    )}
                    {visibleColumns.includes('Property') && (
                      <TableCell className="px-4 py-3 text-start">
                        <div>
                          <span className="block font-medium text-gray-800 text-theme-sm dark:text-white/90">
                            {callLog.Property.name}
                          </span>
                          <span className="block text-gray-500 text-theme-xs dark:text-gray-400">
                            {callLog.Property.Location}
                          </span>
                        </div>
                      </TableCell>
                    )}
                    {visibleColumns.includes('number_of_call') && (
                      <TableCell className="px-4 py-3 text-start">
                        <div className="flex items-center justify-center w-8 h-8 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-full font-medium text-sm">
                          {callLog.number_of_call}
                        </div>
                      </TableCell>
                    )}
                    {visibleColumns.includes('number_of_site_visit') && (
                      <TableCell className="px-4 py-3 text-start">
                        <div className="flex items-center justify-center w-8 h-8 bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded-full font-medium text-sm">
                          {callLog.number_of_site_visit}
                        </div>
                      </TableCell>
                    )}
                    {visibleColumns.includes('last_status') && (
                      <TableCell className="px-4 py-3 text-start">
                        <Badge
                          size="sm"
                          color={
                            callLog.last_status === "Closed Won"
                              ? "success"
                              : callLog.last_status === "Closed Lost" || callLog.last_status === "Not Interested"
                              ? "error"
                              : callLog.last_status === "Hot Lead" || callLog.last_status === "Interested"
                              ? "warning"
                              : callLog.last_status === "In Progress"
                              ? "info"
                              : "dark"
                          }
                        >
                          {callLog.last_status}
                        </Badge>
                      </TableCell>
                    )}
                    {visibleColumns.includes('last_status_date') && (
                      <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                        {callLog.last_status_date}
                      </TableCell>
                    )}
                    {visibleColumns.includes('followUpRequired') && (
                      <TableCell className="px-4 py-3 text-start">
                        <Badge
                          size="sm"
                          color={callLog.followUpRequired ? "warning" : "success"}
                        >
                          {callLog.followUpRequired ? "Required" : "Not Required"}
                        </Badge>
                      </TableCell>
                    )}
                    {visibleColumns.includes('followupDate') && (
                      <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                        {callLog.followupDate}
                      </TableCell>
                    )}
                    {visibleColumns.includes('register_date') && (
                      <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                        {callLog.register_date}
                      </TableCell>
                    )}
                    <TableCell className="px-4 py-3 text-start">
                      <ActionMenu callLog={callLog} onSelect={handleActionSelect} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center">
            <span className="text-sm text-gray-700 dark:text-gray-300">
              Showing{" "}
              <span className="font-medium">{startIndex + 1}</span>
              {" "}to{" "}
              <span className="font-medium">
                {Math.min(endIndex, filteredCallLogs.length)}
              </span>
              {" "}of{" "}
              <span className="font-medium">{filteredCallLogs.length}</span>
              {" "}results
            </span>
          </div>
          <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
        </div>
      )}

      {/* No results message */}
      {filteredCallLogs.length === 0 && (
        <div className="py-8 text-center">
          <p className="text-gray-500 dark:text-gray-400">
            No call logs found matching your search.
          </p>
        </div>
      )}
    </div>
  );
}
